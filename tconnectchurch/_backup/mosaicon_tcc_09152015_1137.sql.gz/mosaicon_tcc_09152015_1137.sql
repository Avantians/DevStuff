-- MySQL dump 10.14  Distrib 5.5.44-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: mosaicon_tcc
-- ------------------------------------------------------
-- Server version	5.5.42-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `advertises`
--

DROP TABLE IF EXISTS `advertises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertises` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(512) NOT NULL,
  `fulltxt` mediumtext NOT NULL,
  `linkfile` text NOT NULL,
  `filename` text NOT NULL,
  `filesize` int(11) NOT NULL,
  `urls` text NOT NULL,
  `target_window` varchar(16) NOT NULL,
  `extra_class` varchar(128) NOT NULL,
  `position` varchar(64) DEFAULT 'A01',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `views` int(11) NOT NULL DEFAULT '0',
  `starting_date` date NOT NULL,
  `ending_date` date NOT NULL,
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertises`
--

LOCK TABLES `advertises` WRITE;
/*!40000 ALTER TABLE `advertises` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertises_group`
--

DROP TABLE IF EXISTS `advertises_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertises_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertises_group`
--

LOCK TABLES `advertises_group` WRITE;
/*!40000 ALTER TABLE `advertises_group` DISABLE KEYS */;
INSERT INTO `advertises_group` VALUES (1,'FrontPage 01','FP01');
INSERT INTO `advertises_group` VALUES (2,'FrontPage 02','FP02');
INSERT INTO `advertises_group` VALUES (3,'FrontPage 03','FP03');
INSERT INTO `advertises_group` VALUES (4,'Footer 01','F01');
INSERT INTO `advertises_group` VALUES (5,'Footer 02','F02');
INSERT INTO `advertises_group` VALUES (6,'Footer 03','F03');
INSERT INTO `advertises_group` VALUES (7,'Footer 04','F04');
INSERT INTO `advertises_group` VALUES (8,'Footer 05','F05');
INSERT INTO `advertises_group` VALUES (9,'Footer 06','F06');
INSERT INTO `advertises_group` VALUES (10,'Footer 07','F07');
INSERT INTO `advertises_group` VALUES (11,'PageSide 01','PS01');
INSERT INTO `advertises_group` VALUES (12,'PageSide 02','PS02');
INSERT INTO `advertises_group` VALUES (13,'PageSide 03','PS03');
INSERT INTO `advertises_group` VALUES (14,'PageSide 04','PS04');
INSERT INTO `advertises_group` VALUES (15,'PageSide 05','PS05');
INSERT INTO `advertises_group` VALUES (16,'PageSide 06','PS06');
INSERT INTO `advertises_group` VALUES (17,'PageSide 07','PS07');
INSERT INTO `advertises_group` VALUES (18,'GroupAds 01','GA01');
INSERT INTO `advertises_group` VALUES (19,'GroupAds 02','GA02');
INSERT INTO `advertises_group` VALUES (20,'GroupAds 03','GA03');
INSERT INTO `advertises_group` VALUES (21,'GroupAds 04','GA04');
INSERT INTO `advertises_group` VALUES (22,'GroupAds 05','GA05');
INSERT INTO `advertises_group` VALUES (23,'GroupAds 06','GA06');
INSERT INTO `advertises_group` VALUES (24,'GroupAds 07','GA07');
INSERT INTO `advertises_group` VALUES (25,'GroupAds 08','GA08');
INSERT INTO `advertises_group` VALUES (26,'GroupAds 09','GA09');
INSERT INTO `advertises_group` VALUES (27,'GroupAds 10','GA10');
INSERT INTO `advertises_group` VALUES (28,'GroupAds 11','GA11');
INSERT INTO `advertises_group` VALUES (29,'GroupAds 12','GA12');
INSERT INTO `advertises_group` VALUES (30,'GroupAds 13','GA13');
INSERT INTO `advertises_group` VALUES (31,'GroupAds 14','GA14');
INSERT INTO `advertises_group` VALUES (32,'GroupAds 15','GA15');
INSERT INTO `advertises_group` VALUES (33,'_Sponsors','sponsors');
INSERT INTO `advertises_group` VALUES (34,'_Partners','partners');
/*!40000 ALTER TABLE `advertises_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertises_pages`
--

DROP TABLE IF EXISTS `advertises_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertises_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `adsfulltxt` mediumtext NOT NULL,
  `pageid` mediumtext NOT NULL,
  `select_opt` varchar(16) NOT NULL,
  `ads_group` varchar(64) NOT NULL,
  `position` varchar(64) NOT NULL,
  `outsideclass` varchar(64) NOT NULL,
  `innerclass` varchar(64) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access_level` tinyint(3) NOT NULL DEFAULT '7',
  `group_level` tinyint(3) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertises_pages`
--

LOCK TABLES `advertises_pages` WRITE;
/*!40000 ALTER TABLE `advertises_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertises_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apps_pages`
--

DROP TABLE IF EXISTS `apps_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apps_pages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `app_position` varchar(32) NOT NULL,
  `app_node` varchar(32) NOT NULL,
  `pageid` mediumtext NOT NULL,
  `params` mediumtext NOT NULL,
  `ordering` int(11) NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apps_pages`
--

LOCK TABLES `apps_pages` WRITE;
/*!40000 ALTER TABLE `apps_pages` DISABLE KEYS */;
INSERT INTO `apps_pages` VALUES (1,1,'top_menu','modules','[1];[2];[3];[4];[5];[6];[7];[8];[9];[10];[11];[12];[13];[14]','all#',0,1);
INSERT INTO `apps_pages` VALUES (2,2,'breadcrumb','modules','[2];[3];[4];[5];[6];[7];[8];[9];[10];[11];[12];[13];[14]','',0,1);
INSERT INTO `apps_pages` VALUES (3,3,'footer','modules','[1];[2];[3];[4];[5];[6];[7];[8];[9];[10];[11];[12];[13];[14]','all#',0,1);
INSERT INTO `apps_pages` VALUES (7,7,'user3','modules','[1];[2];[3];[5];[6];[7];[8];[9];[10];[11];[12];[13];[14]','',0,1);
INSERT INTO `apps_pages` VALUES (8,8,'toppage','modules','[3]','',0,1);
INSERT INTO `apps_pages` VALUES (9,9,'left','modules','[2];[3];[4]','',0,1);
INSERT INTO `apps_pages` VALUES (10,10,'left','modules','[5];[6];[7]','',0,1);
INSERT INTO `apps_pages` VALUES (11,11,'left','modules','[8];[9];[10];[14]','',0,1);
INSERT INTO `apps_pages` VALUES (12,12,'left','modules','[11];[12];[13]','',0,1);
/*!40000 ALTER TABLE `apps_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `title_alias` varchar(255) NOT NULL,
  `fulltxt` text NOT NULL,
  `summarytxt` mediumtext NOT NULL,
  `thumbnail` mediumtext NOT NULL,
  `qrcode` mediumtext NOT NULL,
  `embed_code` mediumtext NOT NULL,
  `embed_bigcode` mediumtext NOT NULL,
  `linkfile` mediumtext NOT NULL,
  `filename` text NOT NULL,
  `filesize` int(11) unsigned NOT NULL DEFAULT '0',
  `urls` mediumtext NOT NULL,
  `usable` tinyint(1) NOT NULL DEFAULT '1',
  `sectionid` int(11) NOT NULL,
  `categoriesid` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL,
  `host` varchar(128) NOT NULL,
  `casting_description` varchar(255) NOT NULL,
  `casting_date` date NOT NULL DEFAULT '0000-00-00',
  `metatitle` mediumtext NOT NULL,
  `metakey` mediumtext NOT NULL,
  `metadesc` mediumtext NOT NULL,
  `access_level` tinyint(3) NOT NULL,
  `group_level` tinyint(3) NOT NULL,
  `publish` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `notice` tinyint(1) NOT NULL DEFAULT '0',
  `loginDownload` tinyint(1) NOT NULL,
  `downloadAlias` varchar(255) NOT NULL,
  `linkOpt` tinyint(1) NOT NULL,
  `views` int(11) NOT NULL,
  `votes` int(11) NOT NULL,
  `password` varchar(32) NOT NULL,
  `user_ip` varchar(16) NOT NULL DEFAULT '',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_by_alias` varchar(128) NOT NULL,
  `publish_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles_comment`
--

DROP TABLE IF EXISTS `articles_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content_id` int(11) unsigned NOT NULL DEFAULT '0',
  `fulltxt` text NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `password` varchar(32) NOT NULL DEFAULT '',
  `user_ip` varchar(16) NOT NULL DEFAULT '',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles_comment`
--

LOCK TABLES `articles_comment` WRITE;
/*!40000 ALTER TABLE `articles_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `articles_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(510) NOT NULL,
  `fulltxt` mediumtext NOT NULL,
  `linkfile` text NOT NULL,
  `filename` text NOT NULL,
  `filesize` int(10) NOT NULL,
  `urls` text NOT NULL,
  `target_window` varchar(16) NOT NULL,
  `extra_class` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL DEFAULT 'top_banner',
  `pageid` mediumtext NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `views` int(11) NOT NULL DEFAULT '0',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
INSERT INTO `banners` VALUES (1,'Welcome 1','<img src=\"http://www.mosaicone.net/connectchurch/images/connect_church_slogan.png\" alt=\"하나님 사랑 이웃 사랑 / Connect with God Connect with People\" class=\"banner-txt-img\">','','images/201509/top_backgroundsa.png',969007,'','_blank','','top_banner','[1]',1,1,1,0,'2015-09-08 15:38:22',1,'2015-09-08 15:34:55',1);
INSERT INTO `banners` VALUES (2,'Welcome 2','<img src=\"http://www.mosaicone.net/connectchurch/images/connect_church_slogan.png\" alt=\"하나님 사랑 이웃 사랑 / Connect with God Connect with People\" class=\"banner-txt-img\">','','images/201509/top_backgrounds_hands.png',1821424,'','_blank','','top_banner','[1]',2,1,1,0,'2015-09-08 15:38:28',1,'2015-09-08 15:35:30',1);
INSERT INTO `banners` VALUES (3,'교회 소개','','','images/201509/top_backgrounds_prayer.png',1876028,'','_blank','','top_banner','[2];[3];[4]',3,1,1,0,'2015-09-09 15:22:02',1,'2015-09-09 15:22:02',1);
INSERT INTO `banners` VALUES (4,'말씀 커넥트','','','images/201509/top_backgrounds_bible.png',1600287,'','_blank','','top_banner','[5];[6];[7]',4,1,1,0,'2015-09-09 15:22:38',1,'2015-09-09 15:22:38',1);
INSERT INTO `banners` VALUES (5,'삶 커넥트','','','images/201509/top_backgrounds_life.png',1821424,'','_blank','','top_banner','[8];[9];[10];[14]',5,1,1,0,'2015-09-09 15:23:36',1,'2015-09-09 15:23:36',1);
INSERT INTO `banners` VALUES (6,'선교 커넥트','','','images/201509/top_backgrounds_mission.png',1435052,'','_blank','','top_banner','[11];[12];[13]',6,1,1,0,'2015-09-09 15:24:37',1,'2015-09-09 15:24:37',1);
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ctype` varchar(32) DEFAULT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `title` varchar(512) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(128) NOT NULL DEFAULT '',
  `section` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `rssstatus` tinyint(1) NOT NULL,
  `rssstype` varchar(16) NOT NULL,
  `rsstitle` varchar(64) NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access_level` tinyint(3) unsigned NOT NULL DEFAULT '7',
  `group_level` tinyint(3) NOT NULL DEFAULT '1',
  `frontpost` tinyint(1) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`section`,`publish`,`access_level`),
  KEY `idx_section` (`section`),
  KEY `idx_access` (`access_level`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'page',0,'Page','page','',1,'',0,'text','Page',1,1,1,7,1,0,'','2013-05-30 10:14:09');
INSERT INTO `categories` VALUES (2,'forms',0,'Forms','forms','',2,'All of forms',0,'text','Forms',1,1,2,7,1,0,'','2013-09-05 14:22:37');
INSERT INTO `categories` VALUES (3,'forms',0,'Responses','form_responses','',2,'All of Form response',0,'text','Responses',1,1,3,7,1,0,'','2013-09-05 15:25:38');
INSERT INTO `categories` VALUES (4,'casting',0,'말씀의 나눔','All-Sermons','',5,'All Sermons',0,'','',1,1,4,7,1,0,'','2015-09-11 16:58:52');
INSERT INTO `categories` VALUES (5,'board',0,'목회 칼럼','pastoral-column','',4,'목회 칼럼',0,'','',1,1,5,7,1,0,'','2015-09-11 17:00:49');
INSERT INTO `categories` VALUES (6,'board',0,'Quiet Time','Quiet Time','',4,'Quiet Time',0,'','',1,1,6,7,1,0,'','2015-09-11 17:01:54');
INSERT INTO `categories` VALUES (7,'board',0,'온라인 주보','weekly-bulletin','',4,'온라인 주보',0,'','',1,1,7,7,1,0,'','2015-09-11 17:03:11');
INSERT INTO `categories` VALUES (8,'board',0,'삶 속 커넥트','in-life','',4,'삶 속 커넥트',0,'','',1,1,8,7,1,0,'','2015-09-11 17:03:57');
INSERT INTO `categories` VALUES (9,'photo',0,'사진 속 커넥트','in-pictures','',6,'사진 속 커넥트',0,'','',1,1,9,7,1,0,'','2015-09-11 17:05:16');
INSERT INTO `categories` VALUES (10,'board',0,'교회 소식','info-board','',4,'교회 소식',0,'','',1,1,10,7,1,0,'','2015-09-11 17:06:33');
INSERT INTO `categories` VALUES (11,'list_thumb_txt',0,'국내 선교','domestic-mission','',4,'국내 선교',0,'','',1,1,11,7,1,0,'','2015-09-11 17:07:29');
INSERT INTO `categories` VALUES (12,'list_thumb_txt',0,'국외 선교','overseas-mission','',4,'국외 선교',0,'','',1,1,12,7,1,0,'','2015-09-11 17:08:47');
INSERT INTO `categories` VALUES (13,'list_thumb_txt',0,'협력 단체','cooperating-group','',4,'협력 단체',0,'','',1,1,13,7,1,0,'','2015-09-11 17:09:32');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_opt`
--

DROP TABLE IF EXISTS `core_opt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_opt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `value_name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `coregroup` varchar(1) NOT NULL DEFAULT 'a',
  `coreshow` tinyint(1) NOT NULL DEFAULT '1',
  `name` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_opt`
--

LOCK TABLES `core_opt` WRITE;
/*!40000 ALTER TABLE `core_opt` DISABLE KEYS */;
INSERT INTO `core_opt` VALUES (1,'Language','CONFIG_LANAGUAGE','english',1,1,'a',1,'Site Language - english');
INSERT INTO `core_opt` VALUES (2,'Site Title','CONFIG_SITE','mosaicone.net/tconnectchurch',2,1,'a',1,'Site Title');
INSERT INTO `core_opt` VALUES (3,'Site URL','CONFIG_SITE_URL','http://www.mosaicone.net/tconnectchurch',4,1,'a',1,'Site URL');
INSERT INTO `core_opt` VALUES (4,'Site URL for SSL','CONFIG_SITE_URL_SSL','https://www.mosaicone.net/tconnectchurch',6,1,'a',1,'');
INSERT INTO `core_opt` VALUES (5,'Site Name','CONFIG_SITE_NAME','Toronto Connect Church | 토론토 커넥트 교회',3,1,'a',1,'Site Name');
INSERT INTO `core_opt` VALUES (6,'Administrator Full Name','CONFIG_ADMIN_NAME','Site Adminitstrator',7,1,'a',1,'Name of Administrator');
INSERT INTO `core_opt` VALUES (7,'Site Main Email','CONFIG_SITE_EMAIL','tconnectchurch&#64;gmail.com',8,1,'a',1,'Main Email to send email from the site');
INSERT INTO `core_opt` VALUES (8,'Site Administrator Email','CONFIG_ADMIN_EMAIL','tconnectchurch&#64;gmail.com',9,1,'a',1,'Administrator email for site\'s notification');
INSERT INTO `core_opt` VALUES (9,'Default Meta Title','CONFIG_DEFAULT_META_TITLE','Toronto Connect Church | 토론토 커넥트 교회',1,1,'b',1,'Default Meta Title for a page');
INSERT INTO `core_opt` VALUES (10,'Default Meta Keywords','CONFIG_DEFAULT_META_KEYWORDS','Toronto Connect Church, 토론토 커넥트 교회',2,1,'b',1,'Default Meta Keywords for a page');
INSERT INTO `core_opt` VALUES (11,'Default Meta Description','CONFIG_DEFAULT_META_DESCRIPTIONS','Connect with GOD, Connect with People and Connect with World',3,1,'b',1,'Default Meta Description for a page');
INSERT INTO `core_opt` VALUES (12,'Default Favorite icon','CONFIG_SITE_FAVICON','favicon.ico',10,1,'a',1,'File name and Location for site favicon');
INSERT INTO `core_opt` VALUES (13,'Front-end HTML Template','CONFIG_FRONT_TEMPLATE','tconnectchurch',11,1,'a',1,'Default Design Name for the front-end - ONLY FOLDER Name of design');
INSERT INTO `core_opt` VALUES (14,'Back-end HTML Template','CONFIG_BACKEND_TEMPLATE','default',12,1,'a',1,'Default Design Name for the back-end - ONLY FOLDER Name of design');
INSERT INTO `core_opt` VALUES (15,'Number of articles per page','CONFIG_HOW_MANY_ARTICLES_PER_PAGE','15',10,1,'d',1,'10');
INSERT INTO `core_opt` VALUES (16,'Number of pages per block','CONFIG_HOW_MANY_PAGES_PER_BLOCK','12',9,1,'d',1,'');
INSERT INTO `core_opt` VALUES (17,'Number of blogs per page','CONFIG_HOW_MANY_BLOGS_PER_PAGE','3',9,1,'d',1,'');
INSERT INTO `core_opt` VALUES (18,'Date short format','CONFIG_DATE_FORMAT_SHORT','%m/%d/%Y',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (19,'Max. Length of URL ','CONFIG_MAX_URL_LENGTH','200',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (20,'Width of Thumbnail','CONFIG_THUMB_WIDTH','600',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (21,'Height of Thumbnail','CONFIG_THUMB_HEIGHT','600',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (22,'Width of Front thumbnail','CONFIG_FRONT_THUMB_WIDTH','105',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (23,'Height of Front thumbnail','CONFIG_FRONT_THUMB_HEIGHT','105',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (24,'Want to calculate image size?','CONFIG_CALCULATE_IMAGE_SIZE','true',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (25,'Image required?','CONFIG_IMAGE_REQUIRED','true',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (26,'Warning  for missing template file','CONFIG_TEMPLATE_WARN_TXT','<font color=\"red\"><b>Template File Not Found! Looking for template:</b></font>&nbsp;&nbsp;',11,1,'a',0,'');
INSERT INTO `core_opt` VALUES (30,'Session Life time for front-end','CONFIG_LIFETIME','1800',2,1,'c',1,'');
INSERT INTO `core_opt` VALUES (31,'Session Life time for back-end','CONFIG_LIFETIME_ADMIN','3600',3,1,'c',1,'');
INSERT INTO `core_opt` VALUES (32,'Folder for uploaded images','CONFIG_FILES_UPLOAD_IMAGES','images/',5,1,'c',1,'');
INSERT INTO `core_opt` VALUES (33,'Folder for uploaded documents','CONFIG_FILES_UPLOAD_DOCS','docs/',6,1,'c',1,'');
INSERT INTO `core_opt` VALUES (34,'Folder for uploaded videos','CONFIG_FILES_UPLOAD_VOD','vods/',7,1,'c',1,'');
INSERT INTO `core_opt` VALUES (35,'Folder for uploaded musics','CONFIG_FILES_UPLOAD_MUSIC','sounds/',8,1,'c',1,'');
INSERT INTO `core_opt` VALUES (36,'SSL&#63;','CONFIG_ENABLE_SSL','true',5,1,'a',1,'SSL Certificates - true or false');
INSERT INTO `core_opt` VALUES (37,'Cookie Domain','CONFIG_COOKIE_DOMAIN','.mosaicone.net',1,1,'c',1,'');
INSERT INTO `core_opt` VALUES (38,'Extra notification email','CONFIG_ADDITIONAL_REGISTER_EMAIL','false',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (39,'Check IP for Session?','CONFIG_CHECK_IP_STATUS_FOR_SESSION','true',0,1,'c',1,'');
INSERT INTO `core_opt` VALUES (40,'Prohibited Language','CONFIG_FORBAD_LANAGUAGE','\"캐쉬스파이더\", \"캐시스파이더\", \"목자르는동영상\", \"목자르는 동영상\", \"ogrish.com\", \"ogrish\", \"오그리시\", \"오그리쉬\", \"오그리쉬닷컴\", \"김선일동영상\", \"김선일 동영상\", \"참수\", \"beheading\", \"007섹스샵\", \"007섹스티브이\", \"007섹스티비\", \"009sex\", \"016섹스닷컴\", \"1004성인용품\", \"100boG\", \"100bozy\", \"10sextv\", \"10섹스티브이\", \"114성인용품\", \"18sex\", \"18sexTV\", \"18x\", \"21섹스넷\", \"24에로라이브\", \"25라이브섹스\", \"33sexymall\", \"365섹스웹\", \"365포르노\", \"365포르노테잎\", \"386섹시매거진\", \"3sextv\", \"4SEX\", \"4changamolca섹스코리아\", \"4kkasi\", \"588\", \"588show\", \"588섹스코리아\", \"588섹스코리아성인방송\", \"588섹스티비\", \"588포르노\", \"5sexshop\", \"69Time\", \"69XY성인디렉토리\", \"69n69성인몰\", \"69sex\", \"69timepornsex\", \"69섹스코리아\", \"69클럽TV\", \"섹스코리아\", \"ADULTMANA\", \"AVmolca\", \"AV갤러리\", \"AV재팬\", \"AdultSearch\", \"AdultSexshop\", \"Adulthumor\", \"Adultzone\", \"Bojyty\", \"Bozicam\", \"GO588TV\", \"GO섹시클럽\", \"HOTWEB\", \"HOTZONE\", \"HardcorePorno\", \"IJSEX\", \"IJ라이브\", \"IJ생방송\", \"IJ에로쇼\", \"IJ특별코너\", \"KRTV\", \"Korea포르노\", \"MANABOZI\", \"MolcaPornoTV\", \"MolcaTV\", \"Molcanara\", \"Molcaparty\", \"Molca테이프\", \"Molca포르노섹스코리아\", \"Molca포르노소라가이드\", \"Molka섹스코리아\", \"Molka코리아섹스\", \"Mulyosex\", \"NEVER-SEX\", \"OIO성인용품\", \"OK성인용품\", \"OK섹스SHOW\", \"PJ\", \"PORNOBOZI\", \"PORNO애니\", \"PleyboG\", \"Pleyboy\", \"Porno바다\", \"SEXBBS\", \"SEXEROS\", \"SEXJAPAN\", \"SEXMOLCA\", \"SEXPDS\", \"SEXWAREZ\", \"SEXYMAP\", \"SEXYX\", \"SEXY화상채팅\", \"SEX로리타\", \"SEX섹스코리아\", \"SOSSEX\", \"SexGoods\", \"SexPorno\", \"Sexpia\", \"Sexwal\", \"Sexyadong\", \"TV플레이보이\", \"X등급\", \"YASATV\", \"Yahanbozi\", \"adult\", \"adultlife\", \"adultvideo\", \"adultzon\", \"av섹스코리아\", \"awoodong\", \"backbojytv\", \"bbagury\", \"bestbozi\", \"binya\", \"byuntaesex\", \"carporno\", \"carsex\", \"clubero\", \"condom\", \"cosex\", \"cosex.net\", \"damoimsex\", \"enterchannel\", \"ero2030\", \"ero69\", \"eroasia\", \"erocine\", \"erosasia\", \"erosian\", \"erostyle\", \"fetish\", \"fetish7\", \"fetishwoman\", \"gabozi\", \"gagasexy\", \"goadult\", \"gocinepia\", \"gojasex\", \"hidden-korea\", \"hiddencam\", \"hotbojy\", \"hotsex\", \"hotsexkorea\", \"ilovesex\", \"joungyang\", \"jungyang\", \"kgirlmolca\", \"kingsex\", \"ksex\", \"ksex.net\", \"kukikorea\", \"live10tv\", \"molca\", \"molca365\", \"molca588\", \"molcaCD\", \"molcaav\", \"molcasex\", \"molcasexnipon\", \"molca섹스\", \"molca섹스코리아\", \"molca포르노\", \"mrcondom\", \"new소라가이드\", \"noode\", \"nopants\", \"nudcouple\", \"nude\", \"nudlnude\", \"oiotv\", \"olotv섹스nipon\", \"oralsextv\", \"playboy\", \"porno\", \"porno-tape\", \"pornomana\", \"pornoplayboy\", \"pornsex\", \"runsex\", \"sex\", \"sex-sayclub\", \"sex123\", \"sex18\", \"sex1818\", \"sex4969\", \"sexTV\", \"sexboard\", \"sexbuin\", \"sexcorea\", \"sexhangame\", \"sexjj\", \"sexkorea\", \"sexkorea,net\", \"sexkorea.com\", \"sexkorea.net\", \"sexkorea21\", \"sexkoreasexkorea\", \"sexmaxx\", \"sexmolka\", \"sexmovie\", \"sexmusa\", \"sexnipon\", \"sexsexy\", \"sexwal.com\", \"sexwall\", \"sexwall.com\", \"sexxmolcatv\", \"sexy\", \"sexyclik\", \"sexyjapan\", \"sexynmall\", \"sexysoul\", \"sora\'sguide\", \"soraguide\", \"sorasguide\", \"sorasguide.com\", \"sunginsite\", \"togoero\", \"tvbozi\", \"tv섹스코리아\", \"twistkim\", \"twistkim.com\", \"videokiller\", \"vip24\", \"viva포르노\", \"warez섹스\", \"whoissex\", \"wonjosex\", \"worldsex\", \"www.porno-tape.com\", \"www.sex123.co.kr\", \"www.sexkorea.net\", \"www.sexwal.com\", \"www.sorasguide.com\", \"www.twistkim.com\", \"xxx\", \"yadong\", \"yadongclub\", \"yadongmolca\", \"yadong섹스코리아\", \"yagood\", \"yahanbamtv\", \"yahannom\", \"yasine\", \"yesmolca\", \"yessex\", \"youngsex\", \"zotte\", \"zungyang\", \"스\", \"스코리아\", \"시넷\", \"콜닷컴\", \"클럽\", \"가가가가섹스샵\", \"가가가섹스WAREZ\", \"가가성인섹스샵\", \"가가성인용품\", \"가가성인용품샵\", \"가가섹스\", \"가가섹스포르노\", \"가가섹스하러다가라\", \"가고파성인용품\", \"가나성인용품전문쇼핑몰\", \"가람섹스성인용품\", \"가마성인쇼핑몰\", \"가면성인용품쇼핑몰\", \"가보자성인용품\", \"가시나무성인용품\", \"가이드성인쇼핑몰\", \"가이드섹스\", \"가인코리아성인용품\", \"가자Molca섹스코리아\", \"가자러브샵\", \"가자미아리\", \"가자성인용품\", \"가자섹스\", \"가자섹스몰\", \"가자섹스자료실\", \"가자섹스코리아\", \"가정섹스전문점\", \"가지와오이성인용품\", \"가지와오이섹스샵\", \"강간\", \"강남카페섹스비디오테이프\", \"강쇠닷컴\", \"강한성인영화\", \"걸섹스코리아갤러리\", \"경고섹스포르노\", \"경마장가는길성인용품\", \"경아닷컴\", \"고69섹슈얼\", \"고공섹스\", \"고려섹시인포디렉토리\", \"고섹스588\", \"고섹스PORNO\", \"고에로TV\", \"고우섹스\", \"고우섹스성인용품점\", \"고자섹스\", \"고추짱\", \"고투에로\", \"고패티쉬\", \"고혈압야동\", \"공짜만화\", \"과부촌\", \"국제성인마트\", \"굿걸TV\", \"굿나잇TV\", \"굿나잇티브이\", \"굿섹스클럽\", \"그룹섹스\", \"근친상간\", \"글래머샵\", \"김마담성인쇼핑몰\", \"꼬추닷컴\", \"나고야섹스미드머니\", \"나나성인용품\", \"나우누리어른만화방\", \"나이스69\", \"나이스성인샵\", \"나조아성인몰\", \"나체\", \"남녀섹시속옷\", \"남녀자위기구\", \"남성단련용품\", \"남성자위기구\", \"네버섹스\", \"네비로스섹스샵\", \"노노티브이\", \"노브라\", \"노브라TV\", \"노팬티브이\", \"논스톱러브성인유머\", \"누나몰카\", \"누두\", \"누드\", \"누드112\", \"누드119\", \"누드25시\", \"누드molcaTV\", \"누드갤러리\", \"누드다이어리\", \"누드모델\", \"누드모아\", \"누드몰카TV\", \"누드뮤직\", \"누드사진\", \"누드섹스\", \"누드쇼\", \"누드스케치\", \"누드집\", \"누드천사\", \"누드커플\", \"누드코리아\", \"누드클럽\", \"누드필름\", \"누드화보\", \"누들누드\", \"뉴스트립\", \"다보자성인영화관\", \"다음섹스\", \"다이섹스\", \"대박성인토탈몰\", \"더티섹스\", \"도쿄섹스\", \"도쿄섹스nipon\", \"동양최고성고전\", \"두두섹스\", \"뒷치기\", \"드림페티쉬\", \"등급보류성인영화관\", \"디지털섹스조선\", \"딸딸이\", \"떡걸\", \"떡치기\", \"라노비아섹스샵\", \"라이브10TV\", \"라이브스트립\", \"러브박사성인용품\", \"러브베드\", \"러브섹시클럽\", \"러브장\", \"러브젤\", \"러브하자성인용품\", \"러브호텔\", \"럭키성인몰\", \"레드섹스tv\", \"레이싱걸\", \"로리타\", \"로리타.\", \"롤리타\", \"류미오\", \"리얼섹스플레이\", \"리얼에로\", \"마나보지\", \"마니아섹스\", \"만화보지\", \"망가\", \"망가짱\", \"모노섹스\", \"모두모아성인용품\", \"모모TV\", \"몰래보기\", \"몰래카메라\", \"몰래캠코더\", \"몰카\", \"몰카365\", \"몰카588\", \"몰카tv\", \"무료망가\", \"무료몰카\", \"무료성인\", \"무료성인동영상\", \"무료성인만화\", \"무료성인방송\", \"무료성인사이트\", \"무료성인싸이트\", \"무료성인엽기\", \"무료성인영화\", \"무료성인정보\", \"무료섹스\", \"무료섹스동영상\", \"무료섹스사이트\", \"무료야동\", \"무료야설\", \"무료포르노\", \"무료포르노동영상\", \"무료헨타이\", \"무전망가\", \"미국뽀르노\", \"미국포르노\", \"미니스커트\", \"미란다성인섹스샵\", \"미소걸성인용품\", \"미소녀\", \"미소녀게임\", \"미소녀섹스가이드\", \"미스누드\", \"미스터콘돔\", \"미스토픽닷컴\", \"미스토픽성인용품점\", \"미시촌\", \"미쎄스터\", \"미아리\", \"미아리2000\", \"미아리588\", \"미아리tv\", \"미아리섹스하리\", \"미아리쇼\", \"미아리텍사스\", \"바나나TV\", \"바나나티비\", \"바이엔에로\", \"밝은세상성인용품\", \"벗기는고스톱\", \"베스트성인용품\", \"베이비아웃성인용품\", \"변태\", \"보스성인클럽\", \"보조기구\", \"보지\", \"보지나라\", \"보지마TV\", \"보지보지\", \"보지털\", \"부부나라\", \"부부섹스\", \"비너스성인용품\", \"빈야\", \"빈야성인\", \"빈야성인와레즈\", \"빠구리\", \"빨간티브이섹스\", \"뽀르노\", \"삐리넷\", \"사까시\", \"사라성인용품점\", \"사랑의침실테크닉\", \"사이버섹스\", \"사창가\", \"색스\", \"색스코리아\", \"샴푸의성인정보\", \"서양동영상\", \"서양뽀르노\", \"성게시판\", \"성고민상담\", \"성과섹스\", \"성기\", \"성보조기구\", \"성상담\", \"성인\", \"성인18번지\", \"성인25시\", \"성인CD\", \"성인IJ\", \"성인갤러리\", \"성인게시판\", \"성인게임\", \"성인그리고섹스\", \"성인극장\", \"성인나라\", \"성인놀이문화\", \"성인누드\", \"성인뉴스\", \"성인대화\", \"성인대화방\", \"성인동영상\", \"성인드라마\", \"성인만화\", \"성인만화나라\", \"성인만화천국\", \"성인망가\", \"성인무료\", \"성인무료동영상\", \"성인무료사이트\", \"성인무료영화\", \"성인무비\", \"성인물\", \"성인미스랭크\", \"성인미팅방\", \"성인방송\", \"성인방송국\", \"성인방송안내\", \"성인배우\", \"성인별곡\", \"성인비됴\", \"성인비디오\", \"성인사이트\", \"성인사이트소개\", \"성인사진\", \"성인상품\", \"성인생방송\", \"성인샵\", \"성인서적\", \"성인성교육스쿨\", \"성인섹스민국\", \"성인섹스코리아\", \"성인소녀경\", \"성인소라가이드\", \"성인소설\", \"성인쇼\", \"성인쇼핑\", \"성인쇼핑몰\", \"성인시트콤\", \"성인싸이트\", \"성인애니\", \"성인애니메이션\", \"성인야설\", \"성인야화\", \"성인에로무비\", \"성인에로영화\", \"성인엽기\", \"성인엽기damoim\", \"성인영상\", \"성인영화\", \"성인영화관\", \"성인영화나라\", \"성인영화방\", \"성인영화세상\", \"성인영화천국\", \"성인와레즈\", \"성인용CD\", \"성인용품\", \"성인용품도매센터\", \"성인용품에로존\", \"성인용품할인매장\", \"성인유머\", \"성인이미지\", \"성인인증&x=23\", \"성인인터넷방송\", \"성인일본\", \"성인자료\", \"성인자료실\", \"성인전용\", \"성인전용관\", \"성인전용정보\", \"성인정보\", \"성인채팅\", \"성인챗\", \"성인천국\", \"성인체위\", \"성인카툰\", \"성인컨텐츠\", \"성인클럽\", \"성인플래쉬\", \"성인플래시\", \"성인화상\", \"성인화상채팅\", \"성일플래쉬\", \"성잉영화\", \"성체위\", \"성클리닉\", \"성테크닉\", \"성폭행\", \"성행위\", \"세븐누드닷컴\", \"세븐섹시\", \"세희야동\", \"섹\", \"섹걸\", \"섹걸닷컴\", \"섹골닷컴\", \"섹마\", \"섹쉬\", \"섹쉬뱅크\", \"섹쉬썸머타임\", \"섹쉬엽기\", \"섹스\", \"섹스19\", \"섹스25시\", \"섹스2TV\", \"섹스588섹스\", \"섹스6mm\", \"섹스700\", \"섹스89\", \"섹스DC\", \"섹스Koreana\", \"섹스Molca섹스코리아\", \"섹스SHOW\", \"섹스TV\", \"섹스and포르노\", \"섹스damoim\", \"섹스daum\", \"섹스molca\", \"섹스molcaTV\", \"섹스molca코리아\", \"섹스molca코리아TV\", \"섹스molca포르노\", \"섹스molka\", \"섹스sayclub\", \"섹스warez\", \"섹스yadong\", \"섹스가이드\", \"섹스갤러리\", \"섹스게시판\", \"섹스고고\", \"섹스굿\", \"섹스나라\", \"섹스나라69\", \"섹스노예\", \"섹스다음\", \"섹스다크\", \"섹스닷컴\", \"섹스데이타100\", \"섹스도우미\", \"섹스동\", \"섹스동영상\", \"섹스드라마\", \"섹스라이브\", \"섹스라이브TV\", \"섹스로봇\", \"섹스리아\", \"섹스리얼\", \"섹스링크\", \"섹스마스터\", \"섹스만화\", \"섹스매거진\", \"섹스모델\", \"섹스모아TV\", \"섹스몰\", \"섹스몰카\", \"섹스무비\", \"섹스무사\", \"섹스뮤직\", \"섹스믹스\", \"섹스바부제펜\", \"섹스벨리\", \"섹스보드\", \"섹스보조기구\", \"섹스보조용품\", \"섹스부인\", \"섹스브라\", \"섹스비디오\", \"섹스비안\", \"섹스사랑\", \"섹스사이트\", \"섹스사진\", \"섹스살롱\", \"섹스샘플\", \"섹스샵\", \"섹스샵2080\", \"섹스샵21\", \"섹스서치\", \"섹스선데이\", \"섹스성인만화\", \"섹스셀카\", \"섹스소나타\", \"섹스소라가이드\", \"섹스소리\", \"섹스시네\", \"섹스심리\", \"섹스씬\", \"섹스아이디\", \"섹스알리바바\", \"섹스애니마나\", \"섹스앤샵\", \"섹스야다이즈\", \"섹스야동\", \"섹스야시네\", \"섹스야호\", \"섹스에니메이션\", \"섹스에로\", \"섹스에로스TV\", \"섹스에로시안\", \"섹스엔바이\", \"섹스엔샵\", \"섹스엠티비닷컴\", \"섹스영상\", \"섹스영화\", \"섹스와레즈\", \"섹스왈\", \"섹스용품\", \"섹스월\", \"섹스월드\", \"섹스웰\", \"섹스인형\", \"섹스일기\", \"섹스자료실\", \"섹스자세\", \"섹스자진\", \"섹스잡지\", \"섹스재팬만화\", \"섹스정보\", \"섹스제이제이\", \"섹스제팬\", \"섹스제펜\", \"섹스조선\", \"섹스조아\", \"섹스조인\", \"섹스지존\", \"섹스짱\", \"섹스찌찌닷콤\", \"섹스채널\", \"섹스챗79\", \"섹스천사\", \"섹스천하\", \"섹스체위\", \"섹스촌\", \"섹스캠프\", \"섹스코러스\", \"섹스코리아\", \"섹스코리아21\", \"섹스코리아79\", \"섹스코리아DAMOIM\", \"섹스코리아MOLCA\", \"섹스코리아OK\", \"섹스코리아TV\", \"섹스코리아jp\", \"섹스코리아warez\", \"섹스코리아걸\", \"섹스코리아넷\", \"섹스코리아라이브\", \"섹스코리아무비\", \"섹스코리아성인엽기\", \"섹스코리아섹스섹스코리아\", \"섹스코리아소라가이드\", \"섹스코리아소라의가이드\", \"섹스코리아앤드섹스코리아\", \"섹스코리아엑스섹스코리아\", \"섹스코리아조선\", \"섹스코리아포르노\", \"섹스코리아하우스\", \"섹스코치\", \"섹스크림\", \"섹스클럽\", \"섹스킴\", \"섹스타임\", \"섹스타임69\", \"섹스테잎\", \"섹스테크닉\", \"섹스토이샵\", \"섹스토이코리아\", \"섹스투데이\", \"섹스트립\", \"섹스파일\", \"섹스파크\", \"섹스포르노\", \"섹스포르노molca\", \"섹스포르노샵\", \"섹스포르노트위스트김\", \"섹스포섹스티비\", \"섹스포유\", \"섹스포인트\", \"섹스포탈\", \"섹스프리덤\", \"섹스피아\", \"섹스하까\", \"섹스하네\", \"섹스하리\", \"섹스한국\", \"섹스해죠\", \"섹스헨타이\", \"섹스호빠\", \"섹스홀\", \"섹시\", \"섹시TV\", \"섹시wave\", \"섹시갤러리\", \"섹시걸\", \"섹시게이트\", \"섹시나라\", \"섹시나이트\", \"섹시누드\", \"섹시뉴스\", \"섹시맵\", \"섹시무비\", \"섹시사진\", \"섹시샵\", \"섹시성인용품\", \"섹시섹스코리아\", \"섹시스타\", \"섹시신문\", \"섹시씨엔엔\", \"섹시아이제이\", \"섹시에로닷컴\", \"섹시엔TV\", \"섹시엔몰\", \"섹시연예인\", \"섹시재팬\", \"섹시제팬\", \"섹시제펜\", \"섹시조선\", \"섹시존\", \"섹시짱\", \"섹시촌\", \"섹시코디\", \"섹시코리아\", \"섹시클럽\", \"섹시클릭\", \"섹시팅하자\", \"섹시팬티\", \"셀카\", \"셀프카메라\", \"소라가이드\", \"소라가이드-에로천국\", \"소라가이드TO\", \"소라가이드앤소라가이드\", \"소라가이드천사\", \"소라스가이드\", \"소라의MissTopic\", \"소라의가이드\", \"소라의섹스코리아가이드\", \"소라의야설공작소\", \"소라의프로포즈\", \"소라즈가이드\", \"쇼걸클럽\", \"쇼우망가\", \"쇼킹동영상\", \"쇼킹섹스\", \"쇼킹섹스코리아\", \"쇼킹에로\", \"숙모보지\", \"스와핑\", \"스타킹포유\", \"신마담\", \"실리콘하우스성인용품\", \"심야TV\", \"심한포르노\", \"싸죠\", \"싹쓰리닷컴\", \"쌕쌕이티비\", \"쌩molca\", \"쌩몰카\", \"쌩보지\", \"쌩보지쑈\", \"쌩쇼\", \"쌩쑈\", \"쌩포르노\", \"씨누드21\", \"씹\", \"아마걸포르노\", \"아색기가\", \"아이러브섹스\", \"아이러브에로스쿨\", \"아이섹스스타\", \"아이제이섹스\", \"아일러브섹스티비\", \"알몸\", \"애로\", \"애로영화\", \"애마부인\", \"애자매\", \"야게임\", \"야게임즈닷넷\", \"야겜\", \"야동\", \"야동게시판\", \"야사\", \"야설\", \"야설공작소\", \"야설신화\", \"야설의문\", \"야시\", \"야시25TV\", \"야시MTV\", \"야시molca\", \"야시걸\", \"야시꾸리\", \"야시네\", \"야시녀\", \"야시랭크\", \"야시룸\", \"야시시\", \"야시캠\", \"야시코리아\", \"야애니\", \"야오이\", \"야하네\", \"야하다\", \"야한\", \"야한거\", \"야한걸\", \"야한것\", \"야한게임\", \"야한그림\", \"야한놈\", \"야한놈SEX\", \"야한누드\", \"야한동영상\", \"야한만화\", \"야한밤\", \"야한밤TV\", \"야한밤티브이\", \"야한사이트\", \"야한사진\", \"야한소설\", \"야한쇼닷컴\", \"야한영화\", \"야한이야기\", \"야한클럽\", \"야해\", \"야해요\", \"어덜트10000\", \"어덜트TV\", \"어덜트라이프\", \"어덜트랜드\", \"어덜트섹시성인영화관\", \"어덜트존\", \"어덜트천사TV\", \"어덜트코믹플러스\", \"어덜트탑10\", \"어덜트피아\", \"에로\", \"에로2002\", \"에로2030\", \"에로69\", \"에로69TV\", \"에로79\", \"에로걸즈\", \"에로게이트\", \"에로게임\", \"에로관\", \"에로극장\", \"에로니폰\", \"에로닷컴\", \"에로당\", \"에로데이\", \"에로동\", \"에로동영상\", \"에로디비\", \"에로무비\", \"에로물\", \"에로뮤직비디오\", \"에로바다\", \"에로방티브\", \"에로배우\", \"에로비\", \"에로비디오\", \"에로비안나이트\", \"에로샵\", \"에로세일\", \"에로섹스TV\", \"에로소라가이드\", \"에로쇼\", \"에로스\", \"에로스TV\", \"에로스데이\", \"에로스아시아\", \"에로스재팬\", \"에로스코리아\", \"에로스쿨\", \"에로스타\", \"에로스타일\", \"에로스페셜\", \"에로스포유\", \"에로시네마\", \"에로시안닷컴\", \"에로시티\", \"에로씨네\", \"에로아시아\", \"에로앤섹스\", \"에로야\", \"에로에스\", \"에로엔조이\", \"에로영화\", \"에로영화관\", \"에로올\", \"에로와이프\", \"에로이브\", \"에로존\", \"에로주\", \"에로촬영현장\", \"에로카\", \"에로클릭\", \"에로투유\", \"에로틱코리아\", \"에로파크\", \"에로패티시\", \"에로팬티\", \"에로플래쉬\", \"에로필름\", \"엑스노브라\", \"엑스모텔\", \"엑스투어덜트\", \"엔터채널\", \"여성성인용품\", \"여성자위기구\", \"여자보지\", \"연인사이성인샵\", \"엽기에로\", \"엽기적인섹스\", \"오나니\", \"오럴섹스\", \"오렌지야동\", \"오르가즘\", \"오마담\", \"오마이에로\", \"오마이포르노\", \"오빠아파\", \"오빠아파닷컴\", \"오빠아퍼\", \"오사카섹스\", \"오성인\", \"오섹스\", \"오섹스야\", \"오섹스테레비\", \"오예성인영화\", \"오이섹스\", \"오케이섹스\", \"오케이섹스TV\", \"오케이섹스molca포르노\", \"오케이섹스티비\", \"옷벗기기\", \"옷벗기기게임\", \"와우섹스\", \"왕가스\", \"용주골\", \"우라본섹스코리아\", \"울트라섹스제팬\", \"원조교제\", \"월드섹스\", \"웹섹스코리아\", \"유호필름\", \"은빛갤러리\", \"음모\", \"이반성인용품몰\", \"이섹스\", \"이승희\", \"인섹스69\", \"인터넷성인방송\", \"일본동영상\", \"일본망가\", \"일본미소녀\", \"일본뽀르노\", \"일본성인만화\", \"일본성인방송\", \"일본섹스\", \"일본포르노\", \"자위\", \"자위기구\", \"자위씬\", \"자위용품\", \"자위코리아\", \"자위행위\", \"자지\", \"재팬마나\", \"재팬만화\", \"재팬팬티\", \"정력강화용품\", \"정력팬티\", \"정력포탈\", \"정사씬모음\", \"정사채널\", \"정세희\", \"정양\", \"정우성인용품전문점\", \"제이제이일본성인만화\", \"졸라야한닷컴\", \"좆물\", \"좋은생활성인용품\", \"진도희\", \"진주희\", \"찌찌\", \"채널레드TV\", \"체위\", \"체위동영상\", \"카섹스\", \"칼라섹스\", \"코리아성인가이드\", \"코리아섹스\", \"코리아섹스샵\", \"코리아스트립닷컴\", \"코리아엑스파일\", \"코리아포로노\", \"코리안걸스\", \"코섹스\", \"콘돔\", \"콘돔나라\", \"콘돔닥터\", \"콘돔몰\", \"콘돔예스\", \"콘돔피아\", \"쿠키걸\", \"쿨에로\", \"크림걸\", \"클럽AV스타\", \"클럽에로\", \"킬링티비\", \"타부코리아\", \"토탈에로\", \"투앤투동거클럽\", \"트위스트김\", \"트위스트김섹스코리아\", \"트위스트김소라가이드\", \"트위스트킴\", \"특수콘돔\", \"패션앤섹스\", \"패티쉬\", \"패티쉬우먼\", \"팬티캔디\", \"페로몬\", \"페티걸\", \"페티쉬\", \"페티쉬러브\", \"페티쉬매거진\", \"페티쉬우먼\", \"페티쉬즘\", \"페티쉬코리아\", \"페티시\", \"펜트하우스\", \"포로노\", \"포르노\", \"포르노24시\", \"포르노CINEMA\", \"포르노CNN\", \"포르노TV\", \"포르노bozi\", \"포르노molca티비\", \"포르노porno섹스코리아\", \"포르노worldcup\", \"포르노yadong\", \"포르노yadong섹스코리아\", \"포르노그라피\", \"포르노로\", \"포르노마나\", \"포르노만화\", \"포르노바다\", \"포르노사진\", \"포르노세상\", \"포르노섹스\", \"포르노섹스TV\", \"포르노섹스마나\", \"포르노섹스소라가이드\", \"포르노섹스코리아\", \"포르노섹스코리아소라가이드\", \"포르노섹스트위스트김\", \"포르노업\", \"포르노오팔팔\", \"포르노월드\", \"포르노집닷컴\", \"포르노천국\", \"포르노천사\", \"포르노테이프\", \"포르노테입\", \"포르노테잎\", \"포르노티비2580\", \"포르노파티\", \"포르노플레이보이\", \"포르로\", \"포카리섹스\", \"프리섹스샵\", \"프리섹스성인용품\", \"프리섹스코리아\", \"플래이보이\", \"플레이보이\", \"플레이보이2030\", \"플레이보이소라가이드\", \"플레이보이온라인\", \"플레이보조개\", \"플레이보지\", \"플레이섹스\", \"피임기구\", \"피임용품\", \"핑크누드샵\", \"핑크섹스샵\", \"핑크코리아\", \"하드코어\", \"하리수누드\", \"하이텔성인CLUB+19\", \"한글섹스사이트\", \"한글섹스코리아\", \"한스테이성인\", \"핫도그TV\", \"핫성인용품\", \"핫섹스\", \"핫섹스재팬\", \"핫섹스코리아\", \"핫포르노\", \"핫포르노섹스\", \"항문섹스\", \"해적,야동\", \"해피데이21성인용품\", \"해피투섹스\", \"향기콘돔\", \"헤라러브샵\", \"헨타이\", \"헨타이망가\", \"헬로우콘돔\", \"헬프섹스\", \"홈섹스TV\", \"화이트섹스라인\", \"후이즈섹스\", \"후장\", \"훔쳐보기\", \"히든포르노\", \"세희네\", \"seheene\", \"세희네쩜넷\", \"무비왕\", \"av배우\", \"잠지만화\", \"야설소라의가이드\", \"섹시녀사진\", \"잠지\", \"uh-oh.com\", \"여성자위시대\", \"www.uh-oh.com\", \"bubunara\", \"공짜성인싸이트\", \"빈야와레즈\", \"코섹스넷\", \"강추야동\", \"케이섹스\", \"옷벗기기게임자신있는\", \"x386\", \"k양비디오\", \"tprtm\", \"옆기성인동영상\", \"잠지털게임\", \"성인사이트메로나\", \"K양\", \"메로나섹스\", \"live10tv.com\", \"옷벗기기게임잡지\", \"도쿄마나\", \"www.sex2848.com\", \"게시판섹스\", \"소라의\", \"섹스존\", \"산소와레즈\", \"야한거벌끈벌끈\", \"섹시포유\", \"한국야동\", \"두두와레즈\", \"섹스망가\", \"야겜usa\", \"포노\", \"야한게임만남의장소\", \"조쟁이.잠지.키스\", \"잠지hentai\", \"여자옷벗기기게임\", \"센스디스\", \"센스디스무비\", \"하소연\", \"성현아누드\", \"성현아누드집\", \"에로키위\", \"은주조갯살\", \"빨간궁뎅이\", \"바부와레즈\", \"당근와레즈\", \"게임와레즈\", \"누드모델가능해\", \"성인메로나\", \"우기와레즈\", \"성현아누드사진\", \"꽃게와레즈\", \"클릭와레즈\", \"메로나,성인\", \"야쿠르트와레즈\", \"오아시스걸\", \"스카이와레즈\", \"신마담와레즈\", \"럭키와레즈\", \"성인방송69채널\", \"야한놈엽기\", \"와레즈코리아\", \"우기의최강와레즈\", \"세희넷\", \"와레즈용\", \"와레즈79\", \"앙마와레즈\", \"스누피야동\", \"누드크로키\", \"59time\", \"공주야동\", \"와래즈$디아블로\", \"에로스토토\", \"블루와레즈\", \"www.live10tv.com\", \"키위와레즈\", \"영화와레즈\", \"www.sex012.com\", \"2040love\", \"성현아누두집\", \"심마담\", \"게시판아동\", \"광년이보지\", \"어두움와레즈\", \"샤먼와레즈\", \"섹시동영상성생활\", \"만두와레즈\", \"ya-han\", \"대박와레즈\", \"신마담pds\", \"69tv\", \"구멍야동\", \"worldsex.com\", \"최강와레즈\", \"게시판성현아\", \"sexy588\", \"몰카넷\", \"와레즈탑\", \"성현아누드갤러리\", \"야동자료실\", \"여고야동\", \"유민누드사진\", \"황수정야동\", \"게시판sex\", \"동거사이트\", \"게시판와레즈\", \"가시나와레즈\", \"어둠와레즈\", \"와레즈사이트\", \"와레즈게임\", \"해적와레즈\", \"퓨전와레즈\", \"유틸와레즈\", \"파랑새와레즈\", \"우기의와레즈\", \"꼬께와레즈\", \"미소녀사진\", \"확끈이와레즈\", \"쿨와레즈\", \"돼지와레즈\", \"브라운와레즈\", \"럭키월드와레즈\", \"무료와레즈\", \"참치와레즈\", \"와레즈타운\", \"메로나.co.kr\", \"메로나\", \"ㄴㄷㅌ\", \"원조tv\", \"빡촌\", \"울트라쏘세지\", \"울트라소세지\", \"목욕탕몰카\", \"은주조개살\", \"봉숙이\", \"live69tv\", \"오현경비디오\", \"꼬추\", \"애무\", \"와레즈\", \"warez\", \"오레즈\", \"오레즈와레즈\", \"졸라맨똥피하기게임다운로드\", \"짱와레즈\", \"짱와레즈닷컴\", \"h양비디오\", \"h양\", \"따무라\", \"무료포르노사이트\", \"야해요야동\", \"야시꾸리닷컴\", \"h양섹스비디오\", \"누드겔러리\", \"야덩\", \"미야리야동\", \"성인폰팅\", \"성인미팅\", \"성인번개\", \"성인만남\", \"성인전화\", \"성인벙개\", \"성인킹카\", \"성인퀸카\", \"졸라섹스\", \"재벌딸포르노\", \"재벌포르노\", \"딸포르노\", \"재벌딸동영상\", \"맛있는섹스\", \"맛있는섹스그리고사랑\", \"미씨촌\", \"권민중누드\", \"권민중누드집\", \"이브의욕망\", \"동거\", \"폰섹스\", \"전화방\", \"번개팅\", \"폰팅\", \"교제알선\", \"클리토리스\", \"포르노사이트\", \"성인정보검색\", \"성인전용서비스\", \"따무라야동\", \"노팬티\", \"딜도\", \"마스터베이션\", \"망까\", \"머니헌터\", \"멜섭\", \"몰래\", \"바구리\", \"밤일\", \"번색\", \"본디지\", \"부랄\", \"빙신\", \"빠걸\", \"빠꾸리\", \"빠라\", \"빠라줘\", \"빨간마후라\", \"빨강마후라\", \"빨기\", \"빨어\", \"빽보지\", \"뽀로노\", \"사까치\", \"색골\", \"성감대\", \"성생활\", \"세엑\", \"섹골\", \"섹녀\", \"섹도우즈\", \"섹무비\", \"섹보지\", \"섹소리\", \"섹티즌\", \"섹할\", \"쇼킹\", \"수타킹\", \"스트립쑈\", \"스쿨걸\", \"쌕스\", \"에니탑\", \"야껨\", \"야똥\", \"야섹\", \"영계\", \"오랄\", \"유흥\", \"육봉\", \"잡년\", \"잡놈\", \"재랄\", \"저년\", \"정사\", \"조루\", \"?\", \"크리토리스\", \"페니스\", \"패티시\", \"페팅\", \"펜티\", \"펨돔\", \"펨섭\", \"포르느\", \"핸타이\", \"헴타이\", \"호빠\", \"혼음\", \"bdsm\", \"bo지\", \"bozi\", \"c2joy\", \"dildo\", \"haduri\", \"hardcore\", \"hentai\", \"IJ\", \"jaji\", \"jgirls\", \"kgirls\", \"nallari\", \"playbog\", \"porn\", \"1090tv\", \"2c8\", \"99bb\", \"민셩야설\", \"보짓\", \"빠굴\", \"빠순이\", \"빨아\", \"뻐킹\", \"수간\", \"쌕쉬\", \"쎄끈\", \"와래즈\", \"애널\", \"오럴\", \"육갑\", \"윤간\", \"음욕\", \"음탕\", \"쪼가리\", \"컴섹\", \"폰색\", \"호스트빠\", \"fuck\", \"gangbang\", \"jfantasy\", \"jasal\", \"playbozi\", \"prno\", \"귀두\", \"구멍\", \"난교\", \"도촬\", \"바이브레이터\", \"불륜\", \"뻐르너\", \"뻐르노\", \"뻘노\", \"뽀르너\", \"뽀지\", \"뽈노\", \"삽입\", \"색쓰\", \"섹쑤\", \"섹쓰\", \"수음\", \"스너프\", \"스왑\", \"애액\", \"엑스터시\", \"야근병동\", \"음란\", \"음부\", \"이반\", \"젖\", \"최음제\", \"치마속\", \"패니스\", \"팬티\", \"퍼르노\", \"포경\", \"포르너\", \"폰\", \"히로뽕\", \"asiangirl\", \"ecstasy\", \"hidden\", \"oral\", \"penis\", \"penthouse\", \"porner\", \"suck\", \"swaping\", \"넣어줘\", \"무삭제원판\", \"색녀\", \"좃물\", \"퇴폐이발소\", \"보짓물\", \"무료성인소설\", \"씹물\", \"스와핑모임\", \"부부교환섹스\", \"섹스나이트\", \"섹스경험담\", \"sora\'s\", \"봉숙이야동\", \"보지빨기\", \"여자옷벗기기\", \"폰섹\", \"캠빨\", \"김완선누드\", \"김완선누드집\", \"이혜영누드\", \"이혜영누드집\", \"이주현누드\", \"이주현누드집\", \"이주현nude\", \"김완선nude\", \"이혜영nude\", \"이지현누드\", \"이지현누드집\", \"지현누드집\", \"이지현누드사진\", \"이지현누드샘플\", \"화상폰팅\", \"티켓다방\", \"여자따먹기\", \"보지먹기\", \"보지따기\", \"포르노키위\", \"포르노배우\", \"성인포르노\", \"공짜포르노\", \"포르노스타\", \"한국포르노\", \"포르노비디오\", \"백지영포르노\", \"포르노자키\", \"슬림페티쉬\", \"무료페티쉬\", \"스타킹페티쉬\", \"무료성인게시판\", \"자위방법\", \"여자자위\", \"화장실몰카\", \"몰카동영상\", \"여고생몰카\", \"몰카리스트\", \"스와핑몰카\", \"이발소몰카\", \"몰카사진\", \"몰카사이트\", \"백지영몰카\", \"변태사진\", \"변태게임\", \"변태만화\", \"변태이야기\", \"변태섹스\", \"변태사이트\", \"아줌마보지\", \"아줌마섹스\", \"아줌마페티쉬\", \"아줌마야동\", \"자지털\", \"보지자지\", \"자지빨기\", \"헤어누드\", \"남자누드\", \"연예인누드\", \"세미누드\", \"고소영누드\", \"셀프누드\", \"무료누드\", \"이효리누드\", \"이혜영누드사진\", \"누드동영상\", \"이헤영누드\", \"여자누드\", \"남성누드\", \"야설게시판\", \"소라야설\", \"무료성인야설\", \"소라의야설\", \"야설록\", \"공짜야설\", \"소라가이드야설\", \"소라의야설가이드\", \"소라야설공작소\", \"야한미소녀\", \"미아리야동\", \"빠구리야동\", \"무료섹스페티쉬\", \"함소원누드\", \"함소원\", \"함소원누드집\", \"함소원nude\", \"소원누드\", \"소원누드집\", \"함소원헤어누드\", \"함소원누드사진\", \"함소원누두\", \"함소원누드보기\",  \"자살\",  \"음독\",  \"청산가리\",  \"청산가루\",  \"테마샵\",  \"테마몰\",  \"테마가게\",  \"테마상점\",  \"모바일몰\",  \"모바일샵\",  \"브랜드샵\",  \"스타샵\",  \"선물상점\",  \"음반상점\",  \"음악상점\",  \"카페상점\",  \"까페상점\",  \"카패상점\",  \"카페상점\",  \"음반가게\",  \"음반샵\",  \"음반몰\",  \"신고센터\",  \"뮤직샵\",  \"뮤직몰\",  \"음악샵\",  \"음악가게\",  \"음악몰\",  \"우수고객\",  \"도우미\",  \"고객센터\",  \"고객센타\",  \"고객샌터\",  \"고객샌타\",  \"할인쿠폰\",  \"카페몰\",  \"카페샵\",  \"까페몰\",  \"까페샵\",  \"카패몰\",  \"카페샵\",  \"까패몰\",  \"까패샵\",  \"캐릭터몰\",  \"캐릭터샵\",  \"케릭터몰\",  \"케릭터샵\",  \"게임머니\",  \"가게주인\",  \"기프트샵\",  \"기프트몰\",  \"아이템샵\",  \"아이템몰\",  \"아바타샵\",  \"아바타몰\",  \"쾌스천맨\",  \"쾌스천걸\",  \"퀘스천맨\",  \"퀘스천걸\",  \"선물가게\",  \"선물몰\",  \"선물샵\",  \"아바타\",  \"주인장\",  \"블로거\",  \"블로깅\",  \"불로거\",  \"불로깅\",  \"볼로거\",  \"볼로깅\",  \"볼르거\",  \"볼르깅\",  \"불르거\",  \"불르깅\",  \"블로그\",  \"블르그\",  \"불로그\",  \"불르그\",  \"볼로그\",  \"볼르그\",  \"네이버\",  \"내이버\",  \"운영자\",  \"관리자\",  \"어드민\",  \"마스터\",  \"엔에치엔\",  \"엔에치앤\",  \"엔애치앤\",  \"엔애치엔\",  \"앤에치엔\",  \"앤에치앤\",  \"앤애치앤\",  \"앤애치엔\",  \"엔에취엔\",  \"엔에취앤\",  \"엔애치앤\",  \"엔애취엔\",  \"앤에취엔\",  \"앤에취앤\",  \"앤애취앤\",  \"앤애취엔\",  \"페이퍼\",  \"지식인\",  \"쥬니버\",  \"미즈클럽\",  \"토크광장\",  \"포토앨범\",  \"마이홈\",  \"엔메거진\",  \"앤메거진\",  \"엔매거진\",  \"앤매거진\",  \"미즈네\",  \"키워드샵\",  \"엔토이\",  \"폴에버\",  \"폴애버\",  \"한게임\",  \"한개임\",  \"엔토이\",  \"앤토이\",  \"블로그씨\",  \"블로그\",  \"네이버\",  \"내이버\",  \"운영자\",  \"관리자\",  \"어드민\",  \"마스터\",  \"엔에치엔\",  \"엔에치앤\",  \"엔애치앤\",  \"엔애치엔\",  \"앤에치엔\",  \"앤에치앤\",  \"앤애치앤\",  \"앤애치엔\",  \"엔에취엔\",  \"엔에취앤\",  \"엔애치앤\",  \"엔애취엔\",  \"앤에취엔\",  \"앤에취앤\",  \"앤애취앤\",  \"앤애취엔\",  \"페이퍼\",  \"지식인\",  \"쥬니버\",  \"미즈클럽\",  \"토크광장\",  \"포토앨범\",  \"마이홈\",  \"엔메거진\",  \"앤메거진\",  \"엔매거진\",  \"앤매거진\",  \"미즈네\",  \"키워드샵\",  \"엔토이\",  \"폴에버\",  \"폴애버\",  \"한게임\",  \"한개임\",  \"엔토이\",  \"앤토이\",  \"매니저\",  \"메니저\",  \"매니져\",  \"메니져\",  \"스탭\",  \"스텝\",  \"갈보\",  \"강간\",  \"개년\",  \"개놈\",  \"개뇬\",  \"개보지\",  \"개삽년\",  \"개새끼\",  \"개세이\",  \"개쉐이\",  \"개자식\",  \"개자지\",  \"개지랄\",  \"그룹섹스\",  \"까자\",  \"꼬추\",  \"노브라\",  \"니미\",  \"니미랄\",  \"니미럴\",  \"니애미\",  \"니에미\",  \"등신\",  \"딸딸이\",  \"또라이\",  \"레즈비언\",  \"멜섹\",  \"몰카\",  \"문섹\",  \"미친넘\",  \"미친년\",  \"미친놈\",  \"미친뇬\",  \"번색\",  \"번색\",  \"번섹\",  \"번섹\",  \"번쌕\",  \"병신\",  \"보지\",  \"본디지\",  \"부랄\",  \"부부교환\",  \"불알\",  \"빙신\",  \"빠구리\",  \"빠굴\",  \"빠꾸리\",  \"빡우리\",  \"빡울\",  \"뽀르노\",  \"새꺄\",  \"새끈\",  \"새끈남\",  \"새끈녀\",  \"새끼\",  \"색남\",  \"색녀\",  \"색녀\",  \"색스\",  \"색폰\",  \"성인만화\",  \"성인물\",  \"성인소설\",  \"성인엽기\",  \"성인영화\",  \"성인용\",  \"성인용품\",  \"성인잡지\",  \"세꺄\",  \"섹\",  \"섹  스\",  \"섹 스\",  \"섹녀\",  \"섹스\",  \"섹스\",  \"쉬팔\",  \"쉬펄\",  \"스발\",  \"스와핑\",  \"스와핑\",  \"시발\",  \"시벌\",  \"시파\",  \"시펄\",  \"십팔금\",  \"쌍넘\",  \"쌍년\",  \"쌍놈\",  \"쌔\",  \"쌔깐\",  \"쌔끈\",  \"쌕쓰\",  \"쌕폰\",  \"썅\",  \"썅넘\",  \"썅년\",  \"썅놈\",  \"썅놈\",  \"쒸팔\",  \"쒸펄\",  \"쓰바\",  \"씌팍\",  \"씨바\",  \"씨발\",  \"씨발\",  \"씨발\",  \"씨발넘\",  \"씨발년\",  \"씨발놈\",  \"씨발뇬\",  \"씨방\",  \"씨방새\",  \"씨버럴\",  \"씨벌\",  \"씨보랄\",  \"씨보럴\",  \"씨부랄\",  \"씨부럴\",  \"씨부리\",  \"씨불\",  \"씨불\",  \"씨브랄\",  \"씨파\",  \"씨파\",  \"씨팍\",  \"씨팔\",  \"씨팔\",  \"씨펄\",  \"씹\",  \"씹물\",  \"씹보지\",  \"씹새\",  \"씹새끼\",  \"씹색\",  \"씹세\",  \"씹세이\",  \"씹쉐\",  \"씹쉐이\",  \"씹쌔\",  \"씹쌔기\",  \"씹자지\",  \"씹창\",  \"씹탱\",  \"씹탱구리\",  \"씹팔\",  \"씹펄\",  \"씹할\",  \"야동\",  \"야동\",  \"야사\",  \"야사\",  \"야설\",  \"야설\",  \"야캠\",  \"야캠\",  \"야한\",  \"야한동영상\",  \"야한사이트\",  \"야한사진\",  \"에로\",  \"에로\",  \"오랄\",  \"와레즈\",  \"와레즈\",  \"원조\",  \"원조교재\",  \"원조교제\",  \"원조교제\",  \"음란\",  \"자위\",  \"자지\",  \"자지\",  \"정품게임\",  \"젖꼭지\",  \"젖탱\",  \"젖탱\",  \"젖탱이\",  \"젼나\",  \"조까\",  \"조까\",  \"졸라\",  \"좃\",  \"좃나\",  \"좃나게\",  \"좆\",  \"좆같\",  \"좆꼴리\",  \"좆나\",  \"좆나게\",  \"좆빠\",  \"좇\",  \"좇\",  \"좇같\",  \"좇꼴려\",  \"좇꼴리\",  \"좇빠\",  \"지랄\",  \"지랄\",  \"지미랄\",  \"체모\",  \"캠색\",  \"캠섹\",  \"캠섹\",  \"컴색\",  \"컴색\",  \"컴섹\",  \"컴섹\",  \"팬티\",  \"페니스\",  \"페니스\",  \"페티쉬\",  \"포르노\",  \"포르노\",  \"폰색\",  \"폰색\",  \"폰섹\",  \"폰섹\",  \"폰섹\",  \"폰쌕\",  \"헨타이\",  \"호로새끼\",  \"호빠\",  \"호스테스바\",  \"호스트바\",  \"화상색\",  \"화상섹\",  \"자살\",  \"음독\",  \"청산가리\",  \"청산가루\"',0,1,'c',0,'');
INSERT INTO `core_opt` VALUES (41,'Use image for page title','CONFIG_USE_IMAGE_PAGE_TITLE','true',5,1,'b',1,'');
INSERT INTO `core_opt` VALUES (42,'Use Meta info for Article','CONFIG_DISPLAY_PAGE_METAS','false',7,1,'d',1,'Display meta information like writer, posted date, and num. of views etc - true or false');
INSERT INTO `core_opt` VALUES (43,'Use Link for page title','CONFIG_USE_TXT_LINK','true',7,1,'b',1,'Using link for the page title as Permalink - true or false');
INSERT INTO `core_opt` VALUES (44,'Use Text Editor','CONFIG_USE_TXT_EDITOR','true',16,1,'a',1,'Option to use rich text editor - true or false');
INSERT INTO `core_opt` VALUES (45,'Notification for new article','CONFIG_EMAIL_NOTICATION_NEW_ARTICLE','true',5,1,'d',1,'');
INSERT INTO `core_opt` VALUES (46,'Show page title','CONFIG_SHOW_TITLE','true',4,1,'b',1,'Display page title [Global option] - true or false');
INSERT INTO `core_opt` VALUES (47,'Root folder name for Upload','CONFIG_FILES_UPLOAD_ROOT','upload/',3,1,'c',1,'');
INSERT INTO `core_opt` VALUES (48,'Site is protected by IP','CONFIG_PROTECT_IP_FRONT','false',10,1,'c',1,'Listed IP addresses will be allowed to access the site');
INSERT INTO `core_opt` VALUES (49,'Admin is protected by IP','CONFIG_PROTECT_IP_BACK','true',12,1,'c',1,'Listed IP addresses will be allowed to access the admin area');
INSERT INTO `core_opt` VALUES (52,'Show page number block','CONFIG_DISPLAY_PAGE_NUM_BLOCK','true',8,1,'d',1,'Display page number block - true or false');
INSERT INTO `core_opt` VALUES (53,'Allow posting an article from front-end','CONFIG_POST_ARTICLE','false',1,1,'d',1,'');
INSERT INTO `core_opt` VALUES (54,'Allow commenting from front-end','CONFIG_POST_COMMENT','false',3,1,'d',1,'');
INSERT INTO `core_opt` VALUES (55,'Comment <strong>ONLY</strong> registered user','CONFIG_COMMENT_REGISTRATION','true',4,1,'d',1,'');
INSERT INTO `core_opt` VALUES (56,'Post <strong>ONLY</strong> registered user','CONFIG_POST_REGISTRATION','true',2,1,'d',1,'');
INSERT INTO `core_opt` VALUES (57,'Notification for new comment','CONFIG_EMAIL_NOTICATION_NEW_COMMENT','true',6,1,'d',1,'');
INSERT INTO `core_opt` VALUES (58,'Show sharing icons','CONFIG_SHARING_ICONS','true',6,1,'b',1,'');
INSERT INTO `core_opt` VALUES (59,'Image size in a page of board','CONFIG_IMG_SIZE_IN_PAGE','600',6,1,'d',1,'Image size in a page of board');
INSERT INTO `core_opt` VALUES (60,'Image size in a list of board','CONFIG_IMG_SIZE_IN_LIST','215',7,1,'d',1,'Image size in a list of board');
INSERT INTO `core_opt` VALUES (61,'Number of Column for photos','CONFIG_NUMBER_IMG','3',8,1,'d',1,'');
INSERT INTO `core_opt` VALUES (62,'USE Twitter meta info','CONFIG_USE_TWITTER_META','true',18,1,'a',1,'If you want to use special meta information for twitter.');
INSERT INTO `core_opt` VALUES (63,'USE Facebook meta info','CONFIG_USE_FB_META','true',19,1,'a',1,'If you want to use special meta information for Facebook.');
INSERT INTO `core_opt` VALUES (64,'Twitter Id','CONFIG_TWITTER_ID','',17,1,'a',1,'');
/*!40000 ALTER TABLE `core_opt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `countries_id` int(11) NOT NULL AUTO_INCREMENT,
  `countries_name` varchar(64) NOT NULL,
  `territory` varchar(64) NOT NULL,
  `countries_iso_code_2` char(2) NOT NULL,
  `countries_iso_code_3` char(3) NOT NULL,
  `address_format_id` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`countries_id`),
  KEY `IDX_COUNTRIES_NAME` (`countries_name`)
) ENGINE=MyISAM AUTO_INCREMENT=242 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Afghanistan','APAC','AF','AFG',1,3);
INSERT INTO `countries` VALUES (2,'Albania','DACH','AL','ALB',1,4);
INSERT INTO `countries` VALUES (3,'Algeria','EMEA','DZ','DZA',1,5);
INSERT INTO `countries` VALUES (4,'American Samoa','APAC','AS','ASM',1,6);
INSERT INTO `countries` VALUES (5,'Andorra','EMEA','AD','AND',1,7);
INSERT INTO `countries` VALUES (6,'Angola','EMEA','AO','AGO',1,8);
INSERT INTO `countries` VALUES (7,'Anguilla','NORAM','AI','AIA',1,9);
INSERT INTO `countries` VALUES (8,'Antarctica','NORAM','AQ','ATA',1,10);
INSERT INTO `countries` VALUES (9,'Antigua and Barbuda','NORAM','AG','ATG',1,11);
INSERT INTO `countries` VALUES (10,'Argentina','LATAM','AR','ARG',1,12);
INSERT INTO `countries` VALUES (11,'Armenia','EMEA','AM','ARM',1,13);
INSERT INTO `countries` VALUES (12,'Aruba','NORAM','AW','ABW',1,14);
INSERT INTO `countries` VALUES (13,'Australia','APAC','AU','AUS',1,15);
INSERT INTO `countries` VALUES (14,'Austria','DACH','AT','AUT',5,16);
INSERT INTO `countries` VALUES (15,'Azerbaijan','EMEA','AZ','AZE',1,17);
INSERT INTO `countries` VALUES (16,'Bahamas','NORAM','BS','BHS',1,18);
INSERT INTO `countries` VALUES (17,'Bahrain','EMEA','BH','BHR',1,19);
INSERT INTO `countries` VALUES (18,'Bangladesh','APAC','BD','BGD',1,20);
INSERT INTO `countries` VALUES (19,'Barbados','NORAM','BB','BRB',1,21);
INSERT INTO `countries` VALUES (20,'Belarus','DACH','BY','BLR',1,22);
INSERT INTO `countries` VALUES (21,'Belgium','EMEA','BE','BEL',1,23);
INSERT INTO `countries` VALUES (22,'Belize','NORAM','BZ','BLZ',1,24);
INSERT INTO `countries` VALUES (23,'Benin','EMEA','BJ','BEN',1,25);
INSERT INTO `countries` VALUES (24,'Bermuda','NORAM','BM','BMU',1,26);
INSERT INTO `countries` VALUES (25,'Bhutan','APAC','BT','BTN',1,27);
INSERT INTO `countries` VALUES (26,'Bolivia','LATAM','BO','BOL',1,28);
INSERT INTO `countries` VALUES (27,'Bosnia and Herzegowina','DACH','BA','BIH',1,29);
INSERT INTO `countries` VALUES (28,'Botswana','EMEA','BW','BWA',1,30);
INSERT INTO `countries` VALUES (29,'Bouvet Island','NORAM','BV','BVT',1,31);
INSERT INTO `countries` VALUES (30,'Brazil','LATAM','BR','BRA',1,32);
INSERT INTO `countries` VALUES (31,'British Indian Ocean Territory','APAC','IO','IOT',1,33);
INSERT INTO `countries` VALUES (32,'Brunei Darussalam','APAC','BN','BRN',1,34);
INSERT INTO `countries` VALUES (33,'Bulgaria','DACH','BG','BGR',1,35);
INSERT INTO `countries` VALUES (34,'Burkina Faso','EMEA','BF','BFA',1,36);
INSERT INTO `countries` VALUES (35,'Burundi','EMEA','BI','BDI',1,37);
INSERT INTO `countries` VALUES (36,'Cambodia','APAC','KH','KHM',1,38);
INSERT INTO `countries` VALUES (37,'Cameroon','EMEA','CM','CMR',1,39);
INSERT INTO `countries` VALUES (38,'Canada','NORAM','CA','CAN',1,2);
INSERT INTO `countries` VALUES (39,'Cape Verde','EMEA','CV','CPV',1,40);
INSERT INTO `countries` VALUES (40,'Cayman Islands','NORAM','KY','CYM',1,41);
INSERT INTO `countries` VALUES (41,'Central African Republic','EMEA','CF','CAF',1,42);
INSERT INTO `countries` VALUES (42,'Chad','EMEA','TD','TCD',1,43);
INSERT INTO `countries` VALUES (43,'Chile','LATAM','CL','CHL',1,44);
INSERT INTO `countries` VALUES (44,'China','APAC','CN','CHN',1,45);
INSERT INTO `countries` VALUES (45,'Christmas Island','APAC','CX','CXR',1,46);
INSERT INTO `countries` VALUES (46,'Cocos (Keeling) Islands','APAC','CC','CCK',1,47);
INSERT INTO `countries` VALUES (47,'Colombia','LATAM','CO','COL',1,48);
INSERT INTO `countries` VALUES (48,'Comoros','EMEA','KM','COM',1,49);
INSERT INTO `countries` VALUES (49,'Congo','EMEA','CG','COG',1,50);
INSERT INTO `countries` VALUES (50,'Cook Islands','APAC','CK','COK',1,51);
INSERT INTO `countries` VALUES (51,'Costa Rica','LATAM','CR','CRI',1,52);
INSERT INTO `countries` VALUES (52,'Cote D\'Ivoire','EMEA','CI','CIV',1,53);
INSERT INTO `countries` VALUES (53,'Croatia','DACH','HR','HRV',1,54);
INSERT INTO `countries` VALUES (54,'Cuba','LATAM','CU','CUB',1,55);
INSERT INTO `countries` VALUES (55,'Cyprus','EMEA','CY','CYP',1,56);
INSERT INTO `countries` VALUES (56,'Czech Republic','DACH','CZ','CZE',1,57);
INSERT INTO `countries` VALUES (57,'Denmark','EMEA','DK','DNK',1,58);
INSERT INTO `countries` VALUES (58,'Djibouti','EMEA','DJ','DJI',1,59);
INSERT INTO `countries` VALUES (59,'Dominica','LATAM','DM','DMA',1,60);
INSERT INTO `countries` VALUES (60,'Dominican Republic','LATAM','DO','DOM',1,61);
INSERT INTO `countries` VALUES (61,'East Timor','APAC','TP','TMP',1,62);
INSERT INTO `countries` VALUES (62,'Ecuador','LATAM','EC','ECU',1,63);
INSERT INTO `countries` VALUES (63,'Egypt','EMEA','EG','EGY',1,64);
INSERT INTO `countries` VALUES (64,'El Salvador','LATAM','SV','SLV',1,65);
INSERT INTO `countries` VALUES (65,'Equatorial Guinea','LATAM','GQ','GNQ',1,66);
INSERT INTO `countries` VALUES (66,'Eritrea','EMEA','ER','ERI',1,67);
INSERT INTO `countries` VALUES (67,'Estonia','DACH','EE','EST',1,68);
INSERT INTO `countries` VALUES (68,'Ethiopia','EMEA','ET','ETH',1,69);
INSERT INTO `countries` VALUES (69,'Falkland Islands (Malvinas)','EMEA','FK','FLK',1,70);
INSERT INTO `countries` VALUES (70,'Faroe Islands','EMEA','FO','FRO',1,71);
INSERT INTO `countries` VALUES (71,'Fiji','APAC','FJ','FJI',1,72);
INSERT INTO `countries` VALUES (72,'Finland','EMEA','FI','FIN',1,73);
INSERT INTO `countries` VALUES (73,'France','EMEA','FR','FRA',1,74);
INSERT INTO `countries` VALUES (74,'France, Metropolitan','EMEA','FX','FXX',1,75);
INSERT INTO `countries` VALUES (75,'French Guiana','LATAM','GF','GUF',1,76);
INSERT INTO `countries` VALUES (76,'French Polynesia','APAC','PF','PYF',1,77);
INSERT INTO `countries` VALUES (77,'French Southern Territories','EMEA','TF','ATF',1,78);
INSERT INTO `countries` VALUES (78,'Gabon','EMEA','GA','GAB',1,79);
INSERT INTO `countries` VALUES (79,'Gambia','EMEA','GM','GMB',1,80);
INSERT INTO `countries` VALUES (80,'Georgia','EMEA','GE','GEO',1,81);
INSERT INTO `countries` VALUES (81,'Germany','DACH','DE','DEU',5,82);
INSERT INTO `countries` VALUES (82,'Ghana','EMEA','GH','GHA',1,83);
INSERT INTO `countries` VALUES (83,'Gibraltar','EMEA','GI','GIB',1,84);
INSERT INTO `countries` VALUES (84,'Greece','EMEA','GR','GRC',1,85);
INSERT INTO `countries` VALUES (85,'Greenland','APAC','GL','GRL',1,86);
INSERT INTO `countries` VALUES (86,'Grenada','LATAM','GD','GRD',1,87);
INSERT INTO `countries` VALUES (87,'Guadeloupe','LATAM','GP','GLP',1,88);
INSERT INTO `countries` VALUES (88,'Guam','APAC','GU','GUM',1,89);
INSERT INTO `countries` VALUES (89,'Guatemala','LATAM','GT','GTM',1,90);
INSERT INTO `countries` VALUES (90,'Guinea','EMEA','GN','GIN',1,91);
INSERT INTO `countries` VALUES (91,'Guinea-bissau','EMEA','GW','GNB',1,92);
INSERT INTO `countries` VALUES (92,'Guyana','LATAM','GY','GUY',1,93);
INSERT INTO `countries` VALUES (93,'Haiti','LATAM','HT','HTI',1,94);
INSERT INTO `countries` VALUES (94,'Heard and Mc Donald Islands','EMEA','HM','HMD',1,95);
INSERT INTO `countries` VALUES (95,'Honduras','LATAM','HN','HND',1,96);
INSERT INTO `countries` VALUES (96,'Hong Kong','APAC','HK','HKG',1,97);
INSERT INTO `countries` VALUES (97,'Hungary','DACH','HU','HUN',1,98);
INSERT INTO `countries` VALUES (98,'Iceland','EMEA','IS','ISL',1,99);
INSERT INTO `countries` VALUES (99,'India','APAC','IN','IND',1,100);
INSERT INTO `countries` VALUES (100,'Indonesia','APAC','ID','IDN',1,101);
INSERT INTO `countries` VALUES (101,'Iran (Islamic Republic of)','EMEA','IR','IRN',1,102);
INSERT INTO `countries` VALUES (102,'Iraq','EMEA','IQ','IRQ',1,103);
INSERT INTO `countries` VALUES (103,'Ireland','EMEA','IE','IRL',1,104);
INSERT INTO `countries` VALUES (104,'Israel','EMEA','IL','ISR',1,105);
INSERT INTO `countries` VALUES (105,'Italy','EMEA','IT','ITA',1,106);
INSERT INTO `countries` VALUES (106,'Jamaica','LATAM','JM','JAM',1,107);
INSERT INTO `countries` VALUES (107,'Japan','APAC-Japan','JP','JPN',1,108);
INSERT INTO `countries` VALUES (108,'Jordan','EMEA','JO','JOR',1,109);
INSERT INTO `countries` VALUES (109,'Kazakhstan','APAC','KZ','KAZ',1,110);
INSERT INTO `countries` VALUES (110,'Kenya','EMEA','KE','KEN',1,111);
INSERT INTO `countries` VALUES (111,'Kiribati','APAC','KI','KIR',1,112);
INSERT INTO `countries` VALUES (112,'Korea, Democratic People\'s Republic of','APAC','KP','PRK',1,113);
INSERT INTO `countries` VALUES (113,'Korea, Republic of','APAC','KR','KOR',1,114);
INSERT INTO `countries` VALUES (114,'Kuwait','EMEA','KW','KWT',1,115);
INSERT INTO `countries` VALUES (115,'Kyrgyzstan','APAC','KG','KGZ',1,116);
INSERT INTO `countries` VALUES (116,'Lao People\'s Democratic Republic','APAC','LA','LAO',1,117);
INSERT INTO `countries` VALUES (117,'Latvia','DACH','LV','LVA',1,118);
INSERT INTO `countries` VALUES (118,'Lebanon','EMEA','LB','LBN',1,119);
INSERT INTO `countries` VALUES (119,'Lesotho','EMEA','LS','LSO',1,120);
INSERT INTO `countries` VALUES (120,'Liberia','EMEA','LR','LBR',1,121);
INSERT INTO `countries` VALUES (121,'Libyan Arab Jamahiriya','EMEA','LY','LBY',1,122);
INSERT INTO `countries` VALUES (122,'Liechtenstein','EMEA','LI','LIE',1,123);
INSERT INTO `countries` VALUES (123,'Lithuania','DACH','LT','LTU',1,124);
INSERT INTO `countries` VALUES (124,'Luxembourg','EMEA','LU','LUX',1,125);
INSERT INTO `countries` VALUES (125,'Macau','APAC','MO','MAC',1,126);
INSERT INTO `countries` VALUES (126,'Macedonia, The Former Yugoslav Republic of','DACH','MK','MKD',1,127);
INSERT INTO `countries` VALUES (127,'Madagascar','','MG','MDG',1,128);
INSERT INTO `countries` VALUES (128,'Malawi','EMEA','MW','MWI',1,129);
INSERT INTO `countries` VALUES (129,'Malaysia','APAC','MY','MYS',1,130);
INSERT INTO `countries` VALUES (130,'Maldives','APAC','MV','MDV',1,131);
INSERT INTO `countries` VALUES (131,'Mali','EMEA','ML','MLI',1,132);
INSERT INTO `countries` VALUES (132,'Malta','EMEA','MT','MLT',1,133);
INSERT INTO `countries` VALUES (133,'Marshall Islands','APAC','MH','MHL',1,134);
INSERT INTO `countries` VALUES (134,'Martinique','LATAM','MQ','MTQ',1,135);
INSERT INTO `countries` VALUES (135,'Mauritania','APAC','MR','MRT',1,136);
INSERT INTO `countries` VALUES (136,'Mauritius','APAC','MU','MUS',1,137);
INSERT INTO `countries` VALUES (137,'Mayotte','EMEA','YT','MYT',1,138);
INSERT INTO `countries` VALUES (138,'Mexico','LATAM','MX','MEX',1,139);
INSERT INTO `countries` VALUES (139,'Micronesia, Federated States of','APAC','FM','FSM',1,140);
INSERT INTO `countries` VALUES (140,'Moldova, Republic of','DACH','MD','MDA',1,141);
INSERT INTO `countries` VALUES (141,'Monaco','EMEA','MC','MCO',1,142);
INSERT INTO `countries` VALUES (142,'Mongolia','APAC','MN','MNG',1,143);
INSERT INTO `countries` VALUES (143,'Montserrat','LATAM','MS','MSR',1,144);
INSERT INTO `countries` VALUES (144,'Morocco','EMEA','MA','MAR',1,145);
INSERT INTO `countries` VALUES (145,'Mozambique','EMEA','MZ','MOZ',1,146);
INSERT INTO `countries` VALUES (146,'Myanmar','APAC','MM','MMR',1,147);
INSERT INTO `countries` VALUES (147,'Namibia','EMEA','NA','NAM',1,148);
INSERT INTO `countries` VALUES (148,'Nauru','APAC','NR','NRU',1,149);
INSERT INTO `countries` VALUES (149,'Nepal','APAC','NP','NPL',1,150);
INSERT INTO `countries` VALUES (150,'Netherlands','EMEA','NL','NLD',1,151);
INSERT INTO `countries` VALUES (151,'Netherlands Antilles','EMEA','AN','ANT',1,152);
INSERT INTO `countries` VALUES (152,'New Caledonia','APAC','NC','NCL',1,153);
INSERT INTO `countries` VALUES (153,'New Zealand','APAC','NZ','NZL',1,154);
INSERT INTO `countries` VALUES (154,'Nicaragua','','NI','NIC',1,155);
INSERT INTO `countries` VALUES (155,'Niger','EMEA','NE','NER',1,156);
INSERT INTO `countries` VALUES (156,'Nigeria','EMEA','NG','NGA',1,157);
INSERT INTO `countries` VALUES (157,'Niue','APAC','NU','NIU',1,158);
INSERT INTO `countries` VALUES (158,'Norfolk Island','APAC','NF','NFK',1,159);
INSERT INTO `countries` VALUES (159,'Northern Mariana Islands','APAC','MP','MNP',1,160);
INSERT INTO `countries` VALUES (160,'Norway','EMEA','NO','NOR',1,161);
INSERT INTO `countries` VALUES (161,'Oman','EMEA','OM','OMN',1,162);
INSERT INTO `countries` VALUES (162,'Pakistan','APAC','PK','PAK',1,163);
INSERT INTO `countries` VALUES (163,'Palau','APAC','PW','PLW',1,164);
INSERT INTO `countries` VALUES (164,'Panama','LATAM','PA','PAN',1,165);
INSERT INTO `countries` VALUES (165,'Papua New Guinea','APAC','PG','PNG',1,166);
INSERT INTO `countries` VALUES (166,'Paraguay','LATAM','PY','PRY',1,167);
INSERT INTO `countries` VALUES (167,'Peru','LATAM','PE','PER',1,168);
INSERT INTO `countries` VALUES (168,'Philippines','APAC','PH','PHL',1,169);
INSERT INTO `countries` VALUES (169,'Pitcairn','APAC','PN','PCN',1,170);
INSERT INTO `countries` VALUES (170,'Poland','DACH','PL','POL',1,171);
INSERT INTO `countries` VALUES (171,'Portugal','EMEA','PT','PRT',1,172);
INSERT INTO `countries` VALUES (172,'Puerto Rico','NORAM','PR','PRI',1,173);
INSERT INTO `countries` VALUES (173,'Qatar','EMEA','QA','QAT',1,174);
INSERT INTO `countries` VALUES (174,'Reunion','APAC','RE','REU',1,175);
INSERT INTO `countries` VALUES (175,'Romania','DACH','RO','ROM',1,176);
INSERT INTO `countries` VALUES (176,'Russian Federation','DACH','RU','RUS',1,177);
INSERT INTO `countries` VALUES (177,'Rwanda','EMEA','RW','RWA',1,178);
INSERT INTO `countries` VALUES (178,'Saint Kitts and Nevis','NORAM','KN','KNA',1,179);
INSERT INTO `countries` VALUES (179,'Saint Lucia','NORAM','LC','LCA',1,180);
INSERT INTO `countries` VALUES (180,'Saint Vincent and the Grenadines','NORAM','VC','VCT',1,181);
INSERT INTO `countries` VALUES (181,'Samoa','APAC','WS','WSM',1,182);
INSERT INTO `countries` VALUES (182,'San Marino','EMEA','SM','SMR',1,183);
INSERT INTO `countries` VALUES (183,'Sao Tome and Principe','EMEA','ST','STP',1,184);
INSERT INTO `countries` VALUES (184,'Saudi Arabia','EMEA','SA','SAU',1,185);
INSERT INTO `countries` VALUES (185,'Senegal','EMEA','SN','SEN',1,186);
INSERT INTO `countries` VALUES (186,'Seychelles','APAC','SC','SYC',1,187);
INSERT INTO `countries` VALUES (187,'Sierra Leone','EMEA','SL','SLE',1,188);
INSERT INTO `countries` VALUES (188,'Singapore','APAC','SG','SGP',4,189);
INSERT INTO `countries` VALUES (189,'Slovakia (Slovak Republic)','DACH','SK','SVK',1,190);
INSERT INTO `countries` VALUES (190,'Slovenia','DACH','SI','SVN',1,191);
INSERT INTO `countries` VALUES (191,'Solomon Islands','APAC','SB','SLB',1,192);
INSERT INTO `countries` VALUES (192,'Somalia','EMEA','SO','SOM',1,193);
INSERT INTO `countries` VALUES (193,'South Africa','EMEA','ZA','ZAF',1,194);
INSERT INTO `countries` VALUES (194,'South Georgia and the South Sandwich Islands','LATAM','GS','SGS',1,195);
INSERT INTO `countries` VALUES (195,'Spain','EMEA','ES','ESP',3,196);
INSERT INTO `countries` VALUES (196,'Sri Lanka','APAC','LK','LKA',1,197);
INSERT INTO `countries` VALUES (197,'St. Helena','APAC','SH','SHN',1,198);
INSERT INTO `countries` VALUES (198,'St. Pierre and Miquelon','APAC','PM','SPM',1,199);
INSERT INTO `countries` VALUES (199,'Sudan','EMEA','SD','SDN',1,200);
INSERT INTO `countries` VALUES (200,'Suriname','LATAM','SR','SUR',1,201);
INSERT INTO `countries` VALUES (201,'Svalbard and Jan Mayen Islands','EMEA','SJ','SJM',1,202);
INSERT INTO `countries` VALUES (202,'Swaziland','EMEA','SZ','SWZ',1,203);
INSERT INTO `countries` VALUES (203,'Sweden','EMEA','SE','SWE',1,204);
INSERT INTO `countries` VALUES (204,'Switzerland','DACH','CH','CHE',1,205);
INSERT INTO `countries` VALUES (205,'Syrian Arab Republic','EMEA','SY','SYR',1,206);
INSERT INTO `countries` VALUES (206,'Taiwan','APAC','TW','TWN',1,207);
INSERT INTO `countries` VALUES (207,'Tajikistan','APAC','TJ','TJK',1,208);
INSERT INTO `countries` VALUES (208,'Tanzania, United Republic of','EMEA','TZ','TZA',1,209);
INSERT INTO `countries` VALUES (209,'Thailand','APAC','TH','THA',1,210);
INSERT INTO `countries` VALUES (210,'Togo','EMEA','TG','TGO',1,211);
INSERT INTO `countries` VALUES (211,'Tokelau','APAC','TK','TKL',1,212);
INSERT INTO `countries` VALUES (212,'Tonga','APAC','TO','TON',1,213);
INSERT INTO `countries` VALUES (213,'Trinidad and Tobago','NORAM','TT','TTO',1,214);
INSERT INTO `countries` VALUES (214,'Tunisia','EMEA','TN','TUN',1,215);
INSERT INTO `countries` VALUES (215,'Turkey','DACH','TR','TUR',1,216);
INSERT INTO `countries` VALUES (216,'Turkmenistan','APAC','TM','TKM',1,217);
INSERT INTO `countries` VALUES (217,'Turks and Caicos Islands','NORAM','TC','TCA',1,218);
INSERT INTO `countries` VALUES (218,'Tuvalu','APAC','TV','TUV',1,219);
INSERT INTO `countries` VALUES (219,'Uganda','EMEA','UG','UGA',1,220);
INSERT INTO `countries` VALUES (220,'Ukraine','DACH','UA','UKR',1,221);
INSERT INTO `countries` VALUES (221,'United Arab Emirates','EMEA','AE','ARE',1,222);
INSERT INTO `countries` VALUES (222,'United Kingdom','EMEA','UK','GBR',1,223);
INSERT INTO `countries` VALUES (223,'United States','NORAM','US','USA',2,1);
INSERT INTO `countries` VALUES (224,'United States Minor Outlying Islands','APAC','UM','UMI',1,224);
INSERT INTO `countries` VALUES (225,'Uruguay','LATAM','UY','URY',1,225);
INSERT INTO `countries` VALUES (226,'Uzbekistan','APAC','UZ','UZB',1,226);
INSERT INTO `countries` VALUES (227,'Vanuatu','APAC','VU','VUT',1,227);
INSERT INTO `countries` VALUES (228,'Vatican City State (Holy See)','EMEA','VA','VAT',1,228);
INSERT INTO `countries` VALUES (229,'Venezuela','LATAM','VE','VEN',1,229);
INSERT INTO `countries` VALUES (230,'Viet Nam','APAC','VN','VNM',1,230);
INSERT INTO `countries` VALUES (231,'Virgin Islands (British)','LATAM','VG','VGB',1,231);
INSERT INTO `countries` VALUES (232,'Virgin Islands (U.S.)','LATAM','VI','VIR',1,232);
INSERT INTO `countries` VALUES (233,'Wallis and Futuna Islands','APAC','WF','WLF',1,233);
INSERT INTO `countries` VALUES (234,'Western Sahara','APAC','EH','ESH',1,234);
INSERT INTO `countries` VALUES (235,'Yemen','EMEA','YE','YEM',1,235);
INSERT INTO `countries` VALUES (236,'Yugoslavia','EMEA','YU','YUG',1,236);
INSERT INTO `countries` VALUES (237,'Zaire','EMEA','ZR','ZAR',1,237);
INSERT INTO `countries` VALUES (238,'Zambia','EMEA','ZM','ZMB',1,238);
INSERT INTO `countries` VALUES (239,'Zimbabwe','EMEA','ZW','ZWE',1,239);
INSERT INTO `countries` VALUES (240,'Montenegro','','ME','MNE',1,240);
INSERT INTO `countries` VALUES (241,'Serbia','','RS','SRB',1,241);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `members_firstname` varchar(32) NOT NULL DEFAULT '',
  `members_lastname` varchar(32) NOT NULL DEFAULT '',
  `members_image` varchar(64) NOT NULL DEFAULT '',
  `members_alias` varchar(32) NOT NULL,
  `members_dob` year(4) NOT NULL DEFAULT '0000',
  `members_username` varchar(255) NOT NULL,
  `members_email` varchar(96) NOT NULL DEFAULT '',
  `members_password` varchar(40) NOT NULL DEFAULT '',
  `members_activation_code` mediumtext NOT NULL,
  `members_city` varchar(32) NOT NULL DEFAULT '',
  `members_province` varchar(32) NOT NULL DEFAULT '',
  `members_country` varchar(32) NOT NULL DEFAULT '',
  `members_phone` varchar(32) NOT NULL DEFAULT '',
  `members_number_article` int(11) NOT NULL DEFAULT '0',
  `members_email_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `members_visited_count` int(11) NOT NULL DEFAULT '0',
  `members_type` tinyint(3) NOT NULL DEFAULT '5',
  `members_level` int(11) NOT NULL DEFAULT '1',
  `members_group_id` int(11) NOT NULL DEFAULT '1',
  `members_registered_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `members_activated_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `members_modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `members_date_of_last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `categoriesid` varchar(255) NOT NULL DEFAULT '0',
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `members_status` tinyint(1) NOT NULL DEFAULT '1',
  `members_option` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (1,'Kenwoo','K','avatar/default-avatar.png','Admin',2000,'ewayplus','iweb&#64;kenwoo.ca','c7dda1073310c702a3504cf80ad28cc6:e7','','mississauga','Ontario','Canada','647-000-000',0,1,183,1,1,0,'2011-10-08 00:00:00','0000-00-00 00:00:00','2014-05-08 16:27:10','2015-09-15 10:07:11','0',1,1,0);
INSERT INTO `members` VALUES (2,'Kenwoo','Kwag','avatar/default-avatar.png','Admin',2000,'siteeditor','iweb&#64;kenwoo.ca','253df96afe5af09f87560afe0b5ad928:c3','a337ff562f94f0305a28f62634356650','','','','647-000-0000',0,1,49,1,1,1,'2013-06-01 15:00:06','2013-06-01 15:03:06','2014-09-16 11:52:01','2014-06-30 12:04:22','0',1,1,1);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_group`
--

DROP TABLE IF EXISTS `members_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_group` (
  `members_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `members_group_name` varchar(32) NOT NULL DEFAULT '',
  `members_group_status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`members_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_group`
--

LOCK TABLES `members_group` WRITE;
/*!40000 ALTER TABLE `members_group` DISABLE KEYS */;
INSERT INTO `members_group` VALUES (1,'Access Everything',1);
INSERT INTO `members_group` VALUES (2,'A Portion',1);
INSERT INTO `members_group` VALUES (3,'B Portion',1);
INSERT INTO `members_group` VALUES (4,'C Portion',1);
/*!40000 ALTER TABLE `members_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_level`
--

DROP TABLE IF EXISTS `members_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_level` (
  `members_level_id` int(11) NOT NULL AUTO_INCREMENT,
  `members_level_name` varchar(32) NOT NULL DEFAULT '',
  `members_level_status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`members_level_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_level`
--

LOCK TABLES `members_level` WRITE;
/*!40000 ALTER TABLE `members_level` DISABLE KEYS */;
INSERT INTO `members_level` VALUES (1,'super site admin',1);
INSERT INTO `members_level` VALUES (2,'site admin',1);
INSERT INTO `members_level` VALUES (3,'manager',1);
INSERT INTO `members_level` VALUES (4,'supervisor',1);
INSERT INTO `members_level` VALUES (5,'editor',1);
INSERT INTO `members_level` VALUES (6,'writer',1);
INSERT INTO `members_level` VALUES (7,'user',1);
/*!40000 ALTER TABLE `members_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_session`
--

DROP TABLE IF EXISTS `members_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_session` (
  `session_id` varchar(255) NOT NULL DEFAULT '0',
  `username` varchar(64) DEFAULT NULL,
  `time` varchar(16) DEFAULT NULL,
  `guest` tinyint(3) DEFAULT '1',
  `userid` int(11) DEFAULT '0',
  `usertype` varchar(64) DEFAULT NULL,
  `userlevel` tinyint(3) NOT NULL DEFAULT '0',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `section` varchar(1) NOT NULL DEFAULT 'f',
  `ipno` double NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_session`
--

LOCK TABLES `members_session` WRITE;
/*!40000 ALTER TABLE `members_session` DISABLE KEYS */;
INSERT INTO `members_session` VALUES ('ae813430f2e962fafa4c18f95b1271a7','iweb&#64;kenwoo.ca','1442326421',9,1,'1',1,0,'b',2268782919.68);
/*!40000 ALTER TABLE `members_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_type`
--

DROP TABLE IF EXISTS `members_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_type` (
  `members_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `members_type_name` varchar(32) NOT NULL DEFAULT '',
  `members_type_status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`members_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_type`
--

LOCK TABLES `members_type` WRITE;
/*!40000 ALTER TABLE `members_type` DISABLE KEYS */;
INSERT INTO `members_type` VALUES (1,'super site admin',1);
INSERT INTO `members_type` VALUES (2,'site admin',1);
INSERT INTO `members_type` VALUES (3,'manager',1);
INSERT INTO `members_type` VALUES (4,'supervisor',1);
INSERT INTO `members_type` VALUES (5,'editor',1);
INSERT INTO `members_type` VALUES (6,'user',1);
/*!40000 ALTER TABLE `members_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(64) DEFAULT NULL,
  `mtitle` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `short_description` text NOT NULL,
  `subclass` varchar(255) NOT NULL DEFAULT '',
  `link` text NOT NULL,
  `target_window` varchar(16) NOT NULL,
  `type` varchar(64) NOT NULL DEFAULT '',
  `publish` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `sublevel` int(11) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `pid` int(11) DEFAULT '0',
  `sid` int(11) DEFAULT '0',
  `hideshow` int(1) DEFAULT '1',
  `access_level` tinyint(3) unsigned NOT NULL DEFAULT '7',
  `group_level` tinyint(3) NOT NULL DEFAULT '1',
  `utaccess_level` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `menutype` (`menutype`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'topmenu','교회 소개','/about-toronto-connect-church','','','/about-toronto-connect-church/greeting','_self','type',1,1,0,0,1,0,0,1,7,1,1);
INSERT INTO `menu` VALUES (2,'topmenu','말씀 커넥트','/sermons','','','/sermons/all-sermons','_self','type',1,1,0,0,2,0,0,1,7,1,1);
INSERT INTO `menu` VALUES (3,'topmenu','삶 커넥트','/connecting','','','/connecting/in-life','_self','type',1,1,0,0,3,0,0,1,7,1,1);
INSERT INTO `menu` VALUES (4,'topmenu','선교 커넥트','/mission','','','/mission/domestic-mission','_self','type',1,1,0,0,4,0,0,1,7,1,1);
INSERT INTO `menu` VALUES (5,'topmenu','인사말','/about-toronto-connect-church/greeting','','','','_self','type',1,1,1,0,5,2,0,1,7,1,1);
INSERT INTO `menu` VALUES (6,'topmenu','섬기는 사람들','/about-toronto-connect-church/people','','','','_self','type',1,1,1,0,6,3,0,1,7,1,1);
INSERT INTO `menu` VALUES (7,'topmenu','예배 및 위치 안내','/about-toronto-connect-church/church-info','','','','_self','type',1,1,1,0,7,4,0,1,7,1,1);
INSERT INTO `menu` VALUES (8,'topmenu','말씀의 나눔','/sermons/all-sermons','','','','_self','type',1,1,2,0,8,5,0,1,7,1,1);
INSERT INTO `menu` VALUES (9,'topmenu','목회 컬럼','/sermons/pastoral-column','','','','_self','type',1,1,2,0,9,6,0,1,7,1,1);
INSERT INTO `menu` VALUES (10,'topmenu','Quiet Time','/sermons/quiet-time','','','','_self','type',1,1,2,0,10,7,0,1,7,1,1);
INSERT INTO `menu` VALUES (11,'topmenu','온라인 주보','/connecting/weekly-bulletin','','','','_self','type',1,1,3,0,11,8,0,1,7,1,1);
INSERT INTO `menu` VALUES (12,'topmenu','삶 속 커넥트','/connecting/in-life','','','','_self','type',1,1,3,0,12,9,0,1,7,1,1);
INSERT INTO `menu` VALUES (13,'topmenu','사진 속 커넥트','/connecting/in-pictures','','','','_self','type',1,1,3,0,13,10,0,1,7,1,1);
INSERT INTO `menu` VALUES (14,'topmenu','국내 선교','/mission/domestic-mission','','','','_self','type',1,1,4,0,14,11,0,1,7,1,1);
INSERT INTO `menu` VALUES (15,'topmenu','국외 선교','/mission/overseas-mission','','','','_self','type',1,1,4,0,15,12,0,1,7,1,1);
INSERT INTO `menu` VALUES (16,'topmenu','협력 단체','/mission/cooperating-group','','','','_self','type',1,1,4,0,16,13,0,1,7,1,1);
INSERT INTO `menu` VALUES (17,'topmenu','교회 소식','/connecting/info-board','','','','_self','type',1,1,3,0,17,14,0,1,7,1,1);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_templates`
--

DROP TABLE IF EXISTS `menu_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(64) NOT NULL DEFAULT '',
  `menuid` int(11) NOT NULL DEFAULT '0',
  `publish` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_templates`
--

LOCK TABLES `menu_templates` WRITE;
/*!40000 ALTER TABLE `menu_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_type`
--

DROP TABLE IF EXISTS `menu_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `type` varchar(32) NOT NULL DEFAULT '',
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_type`
--

LOCK TABLES `menu_type` WRITE;
/*!40000 ALTER TABLE `menu_type` DISABLE KEYS */;
INSERT INTO `menu_type` VALUES (1,'Top Menu','topmenu',1);
INSERT INTO `menu_type` VALUES (2,'Miscellaneous','miscellaneous',1);
/*!40000 ALTER TABLE `menu_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(512) NOT NULL,
  `name` varchar(512) NOT NULL,
  `fulltxt` text NOT NULL,
  `position` varchar(64) NOT NULL,
  `filename` varchar(512) NOT NULL,
  `showtitle` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `inpage` tinyint(1) NOT NULL DEFAULT '0',
  `pageid` mediumtext NOT NULL,
  `select_opt` varchar(16) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access_level` tinyint(3) unsigned NOT NULL DEFAULT '7',
  `group_level` tinyint(3) NOT NULL DEFAULT '1',
  `params` mediumtext NOT NULL,
  `readonly_opt` tinyint(1) NOT NULL DEFAULT '0',
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'Top Menu','top_menu','','top_menu','top_menu',0,0,'','',0,7,1,'',0,1,1,'2015-09-04 14:00:33',1,'2015-09-04 11:14:18',1);
INSERT INTO `modules` VALUES (2,'Breadcrumb','breadcrumb','','breadcrumb','breadcrumb',0,0,'','',0,7,1,'',0,1,1,'2015-09-04 17:12:02',1,'2015-09-04 11:16:24',1);
INSERT INTO `modules` VALUES (3,'Footer','footer','','footer','footer',0,0,'','',0,7,1,'',0,1,1,'2015-09-04 11:44:00',1,'2015-09-04 11:18:20',1);
INSERT INTO `modules` VALUES (7,'Contact Section','contact_section','<section class=\"content\"><div class=\"location-scroll-banner\"><div class=\"container-with-padding\"><ul class=\"front-fixed-left-b\"> <span class=\"ko-txtszie\">모임 안내</span> <li><strong><i class=\"fa fa-check-square\"></i> Worship with All Generation</strong> <ul><li>Sunday Worship Service: <span class=\"gathering-block\">주일 3:00PM (Stone Church)</span></li></ul></li> <li><strong><i class=\"fa fa-check-square\"></i> Weekday Gathering</strong> <ul><li>Wednesday Worship Team Gathering: <span class=\"gathering-block\">수요일 7:00PM (목사관)</span></li></ul></li> <li><strong><i class=\"fa fa-check-square\"></i> Friday Connect Festival </strong> <ul><li>1st Connect - Sports<br/>2nd Connect - Academy<br/>3rd Connect - Worship Festival</li></ul></li> <li><strong><i class=\"fa fa-check-square\"></i> Saturday Gathering</strong> <ul><li>토요 아침 기도회: 토요일 오전 7시  <span class=\"gathering-block\">(ELT/36 Eglinton Ave. West #505)</span></li></ul></li><hr class=\"black-line nodisplay\"></ul><div class=\"front-floated-right-b\"><div class=\"direction-block\"><div class=\"map-side\"> <span class=\"ko-txtszie\">오시는 길</span><strong class=\"neonblue-txt\">Direction</strong><br/>\r\n													One block north of Yonge and Bloor subway station and Bay subway stations.<br/>\r\n													Yonge and Bloor 전철역 또는 Bay 전철역에서 한 블럭 북쪽으로 오시면 Davenport를 만나 45번지를 찾으면 됩니다.\r\n											</div><div class=\"small-map\"><a href=\"https://www.google.ca/maps/place/45+Davenport+Rd,+Toronto,+ON+M5R+1H2/&#64;43.6727332,-79.3898326,17z/data=!3m1!4b1!4m2!3m1!1s0x882b34af3bfc37ab:0x5a9e19ec690eb61b\" title=\"View Google Map\" target=\"_blank\"><img src=\"http://www.mosaicone.net/connectchurch/upload/images/maps.png\"></a></div></div><hr class=\"black-line clearfix\"> <span class=\"ko-txtszie\">주차 안내</span><strong class=\"neonblue-txt\">Free Underground Parking</strong><br/>\r\n									Available for almost all events, enter off Scollard Street. Just push the green button on the control panel.<br/>\r\n									40 Scollard St. 아파트 지하 주차장 입구 판넬의 녹색 버튼을 누르시면 됩니다.\r\n						</div></div></div></section>','user3','',0,0,'','',0,7,1,'',0,1,1,'2015-09-11 11:47:15',1,'2015-09-09 23:18:06',1);
INSERT INTO `modules` VALUES (8,'Staff List','staff_list','<ul class=\"staff_section\">\n<?php\n$count = 1;\n$mquery = $Bon_db->getQuery(\"SELECT * FROM staff WHERE publish = \'1\' AND status = \'1\' ORDER BY ordering\");\nwhile( $_menus5 = $Bon_db->getFetch_Array($mquery) ){\n\n	echo \"<li><img src=\'\".$base_url.\"/upload/\".$_menus5[\'filename\'].\"\' alt=\'\".$_menus5[\'name\'].\"\' width=\'150\'><strong class=\\\"korea-txt\\\">\".$_menus5[\'name\'].\"</strong>&nbsp;&nbsp;|&nbsp;&nbsp;\".$_menus5[\'jobtitle\'].\"<br/><a href=\'mailto:\".$_menus5[\'email\'].\"\' title=\'Email to \".$_menus5[\'name\'].\"\' target=\'_blank\'>\".$_menus5[\'email\'].\"</a>\".$_menus5[\'fulltxt\'].\"</li>\\n\";\n		$count++;\n}\n?></ul>','toppage','',0,1,'','',0,7,1,'',0,1,1,'2015-09-10 21:30:14',1,'2015-09-10 21:30:14',1);
INSERT INTO `modules` VALUES (9,'교회 소개 Side Menu','교회_소개_side_menu','교회 소개','left','',0,0,'','',0,7,1,'',0,1,1,'2015-09-15 10:13:38',1,'2015-09-15 10:09:40',1);
INSERT INTO `modules` VALUES (10,'말씀 커넥트 Side Menu','말씀_커넥트_side_menu','','left','',0,0,'','',0,7,1,'',0,1,1,'2015-09-15 10:10:30',1,'2015-09-15 10:10:30',1);
INSERT INTO `modules` VALUES (11,'삶 커넥트 Side Menu','삶_커넥트_side_menu','','left','',0,0,'','',0,7,1,'',0,1,1,'2015-09-15 10:12:59',1,'2015-09-15 10:11:33',1);
INSERT INTO `modules` VALUES (12,'선교 커넥트 Side Menu','선교_커넥트_side_menu','','left','',0,0,'','',0,7,1,'',0,1,1,'2015-09-15 10:12:39',1,'2015-09-15 10:12:39',1);
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules_position`
--

DROP TABLE IF EXISTS `modules_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules_position` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules_position`
--

LOCK TABLES `modules_position` WRITE;
/*!40000 ALTER TABLE `modules_position` DISABLE KEYS */;
INSERT INTO `modules_position` VALUES (1,'Top Menu','top_menu');
INSERT INTO `modules_position` VALUES (2,'Top Banner','top_banner');
INSERT INTO `modules_position` VALUES (3,'Top JavaScript','top_js');
INSERT INTO `modules_position` VALUES (4,'Top','top');
INSERT INTO `modules_position` VALUES (5,'Banner','banner');
INSERT INTO `modules_position` VALUES (6,'Breadcrumb','breadcrumb');
INSERT INTO `modules_position` VALUES (7,'Right','right');
INSERT INTO `modules_position` VALUES (8,'Left','left');
INSERT INTO `modules_position` VALUES (9,'Footer','footer');
INSERT INTO `modules_position` VALUES (10,'Foot Tracking','foot_tracking');
INSERT INTO `modules_position` VALUES (11,'Head Tracking','head_tracking');
INSERT INTO `modules_position` VALUES (12,'Top in page','toppage');
INSERT INTO `modules_position` VALUES (13,'Bottom in page','bottompage');
INSERT INTO `modules_position` VALUES (14,'Foot JavaScript','foot_js');
INSERT INTO `modules_position` VALUES (15,'User1','user1');
INSERT INTO `modules_position` VALUES (16,'User2','User2');
INSERT INTO `modules_position` VALUES (17,'User3','user3');
/*!40000 ALTER TABLE `modules_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opensef`
--

DROP TABLE IF EXISTS `opensef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opensef` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `tbname` varchar(255) NOT NULL,
  `external` varchar(255) DEFAULT NULL,
  `pid` varchar(255) DEFAULT NULL,
  `direction` char(1) DEFAULT NULL,
  `publish` char(1) NOT NULL DEFAULT '1',
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opensef`
--

LOCK TABLES `opensef` WRITE;
/*!40000 ALTER TABLE `opensef` DISABLE KEYS */;
/*!40000 ALTER TABLE `opensef` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `language_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(512) NOT NULL,
  `title_images` mediumtext NOT NULL,
  `banner_images` mediumtext NOT NULL,
  `filenames` mediumtext NOT NULL,
  `fulltxt` text NOT NULL,
  `frontpage` tinyint(1) NOT NULL DEFAULT '0',
  `showtitle` tinyint(1) NOT NULL DEFAULT '1',
  `embed_code` text NOT NULL,
  `sectionid` int(11) NOT NULL DEFAULT '0',
  `categoriesid` varchar(64) NOT NULL,
  `sections` int(11) NOT NULL DEFAULT '0',
  `categories` int(11) NOT NULL DEFAULT '0',
  `ordering` int(3) NOT NULL DEFAULT '0',
  `metatitle` mediumtext NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access_level` tinyint(3) unsigned NOT NULL DEFAULT '7',
  `group_level` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `useeditor` tinyint(1) NOT NULL DEFAULT '1',
  `readonly_opt` tinyint(1) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0',
  `publish_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access_level`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,'Welcome to Toronto Connect Church','','','','<section class=\"content\">\r\n	<div class=\"container-with-padding\">\r\n			<div class=\"text-center\">\r\n			<p class=\"txtszie text-center\">Connect with <span class=\"red\">GOD</span><br/>Connect with <span class=\"blue\">People</span> and Connect with <span class=\"green\">World</span></p><span class=\"neonblue-txt korea-txt\"><strong>하나님 사랑, 이웃 사랑 그리고 열방 사랑</strong></span></div>\r\n			<hr class=\"black-line\">\r\n\r\n			<div class=\"front-left\">\r\n							<ul class=\"castingthumblist\">\r\n								<li class=\"list_1\">\r\n										<dl>\r\n											<dd><span class=\"img_wrap-1\"><img src=\"http://www.mosaicone.net/connectchurch/upload/images/sermon-thumb.png\"></span></dd>\r\n													<dt class=\"sidedt\">\r\n															<a href=\"http://www.mosaicone.net/connectchurch/#\" title=\"주일 설교\" target=\"_self\">\r\n															<span class=\"vodTitle\">여기는 주일 설교 제목입니다.</span>\r\n															<span class=\"castingDate\">Jul 03, 2015</span>\r\n															<strong>누가복음 1:1</strong></a></dt>\r\n										</dl>\r\n								</li>\r\n							</ul>\r\n							<ul class=\"column-list\">\r\n								<li>\r\n								<a href=\"\" target=\"_self\" title=\"목회 컬럼\">목회 컬럼</a>\r\n								</li>\r\n								\r\n								<li class=\"frontlist1\">\r\n								<a href=\"#\" class=\"item1\" title=\"2015 갤러리아 장학생 선발 안내\" target=\"_self\" onfocus=\"this.blur()\">\r\n								<span class=\"list-no\">01</span>2015 갤러리아 장학생 선발 안내</a>\r\n								</li>\r\n								<li class=\"frontlist2\">\r\n								<a href=\"#\" class=\"item2\" title=\"경상북도 우수 농수산식품 특판전\" target=\"_self\" onfocus=\"this.blur()\">\r\n								<span class=\"list-no\">02</span>경상북도 우수 농수산식품 특판전</a>\r\n								</li>\r\n								<li class=\"frontlist3\">\r\n								<a href=\"#\" class=\"item3\" title=\"제 3회 토론토 일본 여름 축제 3rd Toronto Japanese Summer Festival\" target=\"_self\" onfocus=\"this.blur()\">\r\n								<span class=\"list-no\">03</span>제 3회 토론토 일본 여름 축제 3rd Toronto Ja..</a>\r\n								</li>\r\n								<li class=\"frontlist4\">\r\n								<a href=\"#\" class=\"item4\" title=\"척수 수술시 노인환자 대기시간 더 길다\" target=\"_self\" onfocus=\"this.blur()\">\r\n								<span class=\"list-no\">04</span>척수 수술시 노인환자 대기시간 더 길다</a>\r\n								</li>\r\n								<li class=\"frontlist5\">\r\n								<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n								<span class=\"list-no\">05</span>온주 보수당과 함께한 한인간담회</a>\r\n								</li>\r\n								<li class=\"frontlist6\">\r\n								<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n								<span class=\"list-no\">06</span>온주 보수당과 함께한 한인간담회</a>\r\n								</li>\r\n								\r\n							</ul>\r\n			</div>\r\n\r\n			<div class=\"front-right\">\r\n						<ul class=\"media-list\">\r\n							<li>\r\n									<a href=\"\" target=\"_self\" title=\"Quiet Time with Him\">Quiet Time</a>\r\n							</li>\r\n							<li>\r\n								<div class=\"date\"><a href=\"#\"><span class=\"day\">23</span><span class=\"month\">Jul</span></a></div>\r\n								<div class=\"bd\">\r\n									<h5><a href=\"#\">Eagles Leadership Conference</a></h5>\r\n									<p>Find support and wisdom from Ken Fong and others reflecting together on gender equality in ministry</p>\r\n								</div>\r\n							</li>\r\n\r\n							<li>\r\n								<div class=\"date\"><a href=\"#\"><span class=\"day\">24</span><span class=\"month\">Jul</span></a></div>\r\n								<div class=\"bd\">\r\n									<h5><a href=\"#\">Christians for Biblical Equality 2015</a></h5>\r\n									<p>온주 보수당과 함께한 한인간담회 온주 보수당과 함께한 한인간담회 온주 보수당과 함께한 한인간담회 온주...</p>\r\n								</div>\r\n							</li>\r\n\r\n							<li>\r\n								<div class=\"date\"><a href=\"#\"><span class=\"day\">24</span><span class=\"month\">Jul</span></a></div>\r\n								<div class=\"bd\">\r\n									<h5><a href=\"#\">Christians for Biblical Equality 2015</a></h5>\r\n									<p>Find support and wisdom from Ken Fong and others reflecting together on gender equality in ministry</p>\r\n								</div>\r\n							</li>\r\n						</ul>\r\n			</div>\r\n	</div>\r\n	</section>\r\n\r\n	<section class=\"content\">\r\n		<div class=\"arrow-down-white general-shattered-fixed-banner \">\r\n			<div class=\"container-for-arrow\">\r\n						<ul class=\"oneimgtile\">\r\n								<li class=\"tileB\"><a href=\"#\" title=\"\" target=\"_self\" data-columns=\"#avideo\">\r\n								<div class=\"txtline0\">Interview</div>\r\n								<div class=\"mask\"></div>\r\n								</a><img src=\"http://www.mosaicone.net/connectchurch/upload/images/4620_n.jpg\" alt=\"\"></li>\r\n						</ul>\r\n						<div class=\"tile-section\">\r\n								<ul class=\"twoimgtile\">\r\n										<li class=\"tileA\"><a href=\"#\" title=\"\" target=\"_self\" data-link=\"#what-powua\">\r\n										<div class=\"txtline0\">What ?</div>\r\n										<div class=\"mask\"></div>\r\n										</a><img src=\"http://www.mosaicone.net/connectchurch/upload/images/8890_n.jpg\" alt=\"\"></li>\r\n\r\n										<li class=\"tileB\"><a href=\"#\" title=\"\" target=\"_self\" data-columns=\"#avideo\">\r\n										<div class=\"txtline0\">Interview</div>\r\n										<div class=\"mask\"></div>\r\n										</a><img src=\"http://www.mosaicone.net/connectchurch/upload/images/1523_n.jpg\" alt=\"\"></li>\r\n								</ul>\r\n								\r\n								<ul class=\"threeimgtile extra-top\">\r\n										<li class=\"tileA\"><a href=\"#\" title=\"\" target=\"_self\" data-link=\"#what-powua\">\r\n										<div class=\"txtline0\">What ?</div>\r\n										<div class=\"mask\"></div>\r\n										</a><img src=\"http://www.mosaicone.net/connectchurch/upload/images/3831_n.jpg\" alt=\"\"></li>\r\n\r\n										<li class=\"tileB\"><a href=\"#\" title=\"\" target=\"_self\" data-columns=\"#avideo\">\r\n										<div class=\"txtline0\">Interview</div>\r\n										<div class=\"mask\"></div>\r\n										</a><img src=\"http://www.mosaicone.net/connectchurch/upload/images/2111_n.jpg\" alt=\"\"></li>\r\n										\r\n										<li class=\"tileC\"><a href=\"#\" title=\"\" target=\"_self\" data-link=\"#what-powua\">\r\n										<div class=\"txtline0\">What ?</div>\r\n										<div class=\"mask\"></div>\r\n										</a><img src=\"http://www.mosaicone.net/connectchurch/upload/images/3831_n.jpg\" alt=\"\"></li>										\r\n								</ul>\r\n						</div>\r\n			</div>\r\n		</div>\r\n	</section>\r\n\r\n	<section class=\"content\">\r\n		<div class=\"container-with-padding\">\r\n					<div class=\"front-fixed-one\">\r\n									<ul class=\"column-list\">\r\n										<li>\r\n												<a href=\"\" target=\"_self\" title=\"목회 컬럼\">커넥트 소식</a>\r\n										</li>\r\n										\r\n										<li class=\"frontlist1\">\r\n												<a href=\"#\" class=\"item1\" title=\"2015 갤러리아 장학생 선발 안내\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">01</span>2015 갤러리아 장학생 선발 안내</a>\r\n										</li>\r\n										<li class=\"frontlist2\">\r\n												<a href=\"#\" class=\"item2\" title=\"경상북도 우수 농수산식품 특판전\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">02</span>경상북도 우수 농수산식품 특판전</a>\r\n										</li>\r\n										<li class=\"frontlist3\">\r\n												<a href=\"#\" class=\"item3\" title=\"제 3회 토론토 일본 여름 축제 3rd Toronto Japanese Summer Festival\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">03</span>제 3회 토론토 일본 여름 축제 3rd Toronto Ja..</a>\r\n										</li>\r\n										<li class=\"frontlist4\">\r\n												<a href=\"#\" class=\"item4\" title=\"척수 수술시 노인환자 대기시간 더 길다\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">04</span>척수 수술시 노인환자 대기시간 더 길다</a>\r\n										</li>\r\n										<li class=\"frontlist5\">\r\n												<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">05</span>온주 보수당과 함께한 한인간담회</a>\r\n										</li>\r\n										<li class=\"frontlist6\">\r\n												<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">06</span>온주 보수당과 함께한 한인간담회</a>\r\n										</li>\r\n										<li class=\"frontlist7\">\r\n												<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">07</span>온주 보수당과 함께한 한인간담회</a>\r\n										</li>\r\n										\r\n									</ul>\r\n					</div>\r\n					<div class=\"front-fixed-two\">\r\n									<ul class=\"column-list\">\r\n										<li>\r\n												<a href=\"\" target=\"_self\" title=\"목회 컬럼\">삶 속 커넥트</a>\r\n										</li>\r\n										\r\n										<li class=\"frontlist1\">\r\n												<a href=\"#\" class=\"item1\" title=\"2015 갤러리아 장학생 선발 안내\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">01</span>2015 갤러리아 장학생 선발 안내 안내</a>\r\n										</li>\r\n										<li class=\"frontlist2\">\r\n												<a href=\"#\" class=\"item2\" title=\"경상북도 우수 농수산식품 특판전\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">02</span>경상북도 우수 농수산식품 특판전</a>\r\n										</li>\r\n										<li class=\"frontlist3\">\r\n												<a href=\"#\" class=\"item3\" title=\"제 3회 토론토 일본 여름 축제 3rd Toronto Japanese Summer Festival\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">03</span>제 3회 토론토 일본 여름 축제 3rd Toronto Ja..</a>\r\n										</li>\r\n										<li class=\"frontlist4\">\r\n												<a href=\"#\" class=\"item4\" title=\"척수 수술시 노인환자 대기시간 더 길다\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">04</span>척수 수술시 노인환자 대기시간 더 길다</a>\r\n										</li>\r\n										<li class=\"frontlist5\">\r\n												<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">05</span>온주 보수당과 함께한 한인간담회</a>\r\n										</li>\r\n										<li class=\"frontlist6\">\r\n												<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">06</span>온주 보수당과 함께한 한인간담회</a>\r\n										</li>\r\n										<li class=\"frontlist7\">\r\n												<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">07</span>온주 보수당과 함께한 한인간담회</a>\r\n										</li>										\r\n										\r\n									</ul>\r\n					</div>\r\n					<div class=\"front-fixed-three\">\r\n									<ul class=\"column-list\">\r\n										<li>\r\n												<a href=\"\" target=\"_self\" title=\"목회 컬럼\">선교 속 커넥트</a>\r\n										</li>\r\n										\r\n										<li class=\"frontlist1\">\r\n												<a href=\"#\" class=\"item1\" title=\"2015 갤러리아 장학생 선발 안내\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">01</span>2015 갤러리아 장학생 선발 안내</a>\r\n										</li>\r\n										<li class=\"frontlist2\">\r\n												<a href=\"#\" class=\"item2\" title=\"경상북도 우수 농수산식품 특판전\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">02</span>경상북도 우수 농수산식품 특판전</a>\r\n										</li>\r\n										<li class=\"frontlist3\">\r\n												<a href=\"#\" class=\"item3\" title=\"제 3회 토론토 일본 여름 축제 3rd Toronto Japanese Summer Festival\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">03</span>제 3회 토론토 일본 여름 축제 3rd Toronto Ja..</a>\r\n										</li>\r\n										<li class=\"frontlist4\">\r\n												<a href=\"#\" class=\"item4\" title=\"척수 수술시 노인환자 대기시간 더 길다\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">04</span>척수 수술시 노인환자 대기시간 더 길다</a>\r\n										</li>\r\n										<li class=\"frontlist5\">\r\n												<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">05</span>온주 보수당과 함께한 한인간담회</a>\r\n										</li>\r\n										<li class=\"frontlist6\">\r\n												<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">06</span>온주 보수당과 함께한 한인간담회</a>\r\n										</li>\r\n										<li class=\"frontlist7\">\r\n												<a href=\"#\" class=\"item5\" title=\"온주 보수당과 함께한 한인간담회\" target=\"_self\" onfocus=\"this.blur()\">\r\n												<span class=\"list-no\">07</span>온주 보수당과 함께한 한인간담회</a>\r\n										</li>										\r\n										\r\n									</ul>\r\n					</div>					\r\n		</div>\r\n	</section>',1,0,'',0,'',1,1,1,'Welcome to Toronto Connect Church','','',7,1,1,1,0,0,204,'2015-09-09 23:24:04',1,'2015-09-04 11:09:42',1,'2015-09-09 23:24:04');
INSERT INTO `pages` VALUES (2,0,'인사말','','','','<p><strong>예수</strong>께서 이르시되 네 <strong>마음</strong>을 다하고 <br /><strong>목숨</strong>을 다하고 <strong>뜻</strong>을 다하여<br />주 너의 하나님을 <strong>사랑</strong>하라 하셨으니<br />이것이 크고 첫째되는 계명이요<br />둘째도 그와 같으니 네 <strong>이웃</strong>을 네 자신 같이 <strong>사랑</strong>하라 하셨으니<br />이 두계명이 온 율벌과 선지자의 강령이나라.<br />마태복음 22:37-40</p>\r\n<p>김 지연 목사</p>',0,1,'',0,'',1,1,2,'인사말','','',7,1,1,1,1,0,46,'2015-09-14 15:53:41',1,'2015-09-04 11:38:11',1,'2015-09-14 15:53:41');
INSERT INTO `pages` VALUES (3,0,'섬기는 사람들','','','','<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"/tconnectchurch/upload/images/IMG_1208.jpg\" alt=\"\" width=\"600\" height=\"590\" /></p>',0,1,'',0,'',1,1,3,'섬기는 사람들','','',7,1,1,1,1,0,258,'2015-09-11 11:11:59',1,'2015-09-04 11:39:58',1,'2015-09-11 11:11:59');
INSERT INTO `pages` VALUES (4,0,'예배 및 위치 안내','','','','<ul class=\"service-info\">\r\n  <span class=\"ko-txtszie\">예배 안내</span>\r\n  <li><strong><i class=\"fa fa-check-square\"></i> Worship with All Generation</strong>\r\n    <ul>\r\n      <li>Sunday Worship Service: <span class=\"gathering-block\">주일 3:00PM (Stone Church)</span></li>\r\n    </ul>\r\n  </li>\r\n  <li><strong><i class=\"fa fa-check-square\"></i> Weekday Gathering</strong>\r\n    <ul>\r\n      <li>Wednesday Worship Team Gathering: <span class=\"gathering-block\">수요일 7:00PM (목사관)</span></li>\r\n    </ul>\r\n  </li>\r\n  <li><strong><i class=\"fa fa-check-square\"></i> Friday Connect Festival </strong>\r\n    <ul>\r\n      <li>1st Connect - Sports<br/>\r\n        2nd Connect - Academy<br/>\r\n        3rd Connect - Worship Festival</li>\r\n    </ul>\r\n  </li>\r\n  <li><strong><i class=\"fa fa-check-square\"></i> Saturday Gathering</strong>\r\n    <ul>\r\n      <li>토요 아침 기도회: 토요일 오전 7시 <span class=\"gathering-block\">(ELT/36 Eglinton Ave. West #505)</span></li>\r\n    </ul>\r\n  </li>\r\n</ul>\r\n<hr class=\"divimg clearfix\">\r\n  <span class=\"ko-txtszie\">교회 주소</span><strong class=\"neonblue-txt\">Stone Chruch</strong><br/>\r\n45 Davenport Road Toronto, ON M5R 1H2\r\n  <hr class=\"black-line clearfix\">\r\n    \r\n  <div class=\"direction-block\">\r\n    <div class=\"map-side\"> <span class=\"ko-txtszie\">오시는 길</span><strong class=\"neonblue-txt\">Direction</strong><br/>\r\n      One block north of Yonge and Bloor subway station and Bay subway stations.<br/>\r\n      Yonge and Bloor 전철역 또는 Bay 전철역에서 한 블럭 북쪽으로 오시면 Davenport를 만나 45번지를 찾으면 됩니다. </div>\r\n    <div class=\"small-map\"><a href=\"https://www.google.ca/maps/place/45+Davenport+Rd,+Toronto,+ON+M5R+1H2/&#64;43.6727332,-79.3898326,17z/data=!3m1!4b1!4m2!3m1!1s0x882b34af3bfc37ab:0x5a9e19ec690eb61b\" title=\"View Google Map\" target=\"_blank\"><img src=\"http://www.mosaicone.net/connectchurch/upload/images/maps.png\"></a></div>\r\n  </div>\r\n  <hr class=\"black-line clearfix\">\r\n  <span class=\"ko-txtszie\">주차 안내</span><strong class=\"neonblue-txt\">Free Underground Parking</strong><br/>\r\n  Available for almost all events, enter off Scollard Street. Just push the green button on the control panel.<br/>\r\n  40 Scollard St. 아파트 지하 주차장 입구 판넬의 녹색 버튼을 누르시면 됩니다.\r\n<hr class=\"black-line clearfix\">\r\n  <span class=\"ko-txtszie\">목사관</span><strong class=\"neonblue-txt\">Mailing Address</strong><br/>\r\n  269 Finch Ave. West. North York ON M2R1M8&nbsp;&nbsp;|&nbsp;&nbsp;416-999-7878 & 647.800.0481',0,1,'',0,'',1,1,4,'예배 및 위치 안내','','',7,1,1,1,0,0,59,'2015-09-14 22:01:59',1,'2015-09-04 11:46:12',1,'2015-09-14 22:01:59');
INSERT INTO `pages` VALUES (5,0,'말씀의 나눔','','','','',0,1,'',5,'4',1,1,5,'말씀의 나눔','','',7,1,1,1,1,0,36,'2015-09-11 17:15:58',1,'2015-09-04 11:58:23',1,'2015-09-11 17:15:58');
INSERT INTO `pages` VALUES (6,0,'목회 컬럼','','','','',0,1,'',4,'5',1,1,6,'목회 컬럼','','',7,1,1,1,1,0,5,'2015-09-11 17:16:39',1,'2015-09-04 11:58:41',1,'2015-09-11 17:16:39');
INSERT INTO `pages` VALUES (7,0,'Quiet Time','','','','',0,1,'',4,'6',1,1,7,'Quiet Time','','',7,1,1,1,1,0,4,'2015-09-11 17:17:08',1,'2015-09-04 11:59:01',1,'2015-09-11 17:17:08');
INSERT INTO `pages` VALUES (8,0,'온라인 주보','','','','',0,1,'',4,'7',1,1,8,'온라인 주보','','',7,1,1,1,1,0,2,'2015-09-11 17:18:00',1,'2015-09-04 11:59:30',1,'2015-09-11 17:18:00');
INSERT INTO `pages` VALUES (9,0,'삶 속 커넥트','','','','',0,1,'',4,'8',1,1,9,'삶 속 나눔','','',7,1,1,1,1,0,21,'2015-09-11 17:18:33',1,'2015-09-04 11:59:48',1,'2015-09-11 17:18:33');
INSERT INTO `pages` VALUES (10,0,'사진 속 커넥트','','','','',0,1,'',6,'9',1,1,10,'사진 속 나눔','','',7,1,1,1,1,0,5,'2015-09-11 17:18:58',1,'2015-09-04 12:00:05',1,'2015-09-11 17:18:58');
INSERT INTO `pages` VALUES (11,0,'국내 선교','','','','',0,1,'',4,'11',1,1,11,'국내 선교','','',7,1,1,1,1,0,13,'2015-09-11 17:23:06',1,'2015-09-04 12:00:39',1,'2015-09-11 17:23:06');
INSERT INTO `pages` VALUES (12,0,'국외 선교','','','','',0,1,'',4,'12',1,1,12,'국외 선교','','',7,1,1,1,1,0,2,'2015-09-11 17:23:32',1,'2015-09-04 12:01:01',1,'2015-09-11 17:23:32');
INSERT INTO `pages` VALUES (13,0,'협력 단체','','','','',0,1,'',4,'13',1,1,13,'협력 단체','','',7,1,1,1,1,0,15,'2015-09-11 17:24:18',1,'2015-09-04 12:01:15',1,'2015-09-11 17:24:18');
INSERT INTO `pages` VALUES (14,0,'교회 소식','','','','',0,1,'',4,'10',1,1,14,'교회 소식','','',7,1,1,1,1,0,3,'2015-09-11 17:24:54',1,'2015-09-04 13:04:14',1,'2015-09-11 17:24:54');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `tbname` varchar(255) NOT NULL,
  `stype` varchar(32) NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access_level` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `group_level` tinyint(3) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,'All of Pages','page','','All of pages','pages','page',1,1,1,7,1,'2013-04-25 15:09:17');
INSERT INTO `sections` VALUES (2,'All of Forms','forms','','All of forms','forms','forms',1,1,2,7,1,'2013-04-25 15:08:58');
INSERT INTO `sections` VALUES (5,'All of Casting','casting','','','articles','casting',1,1,4,7,1,'2013-04-25 15:09:04');
INSERT INTO `sections` VALUES (4,'All of Articles','articles','','All of articles','articles','board',1,1,3,7,1,'2013-04-25 15:08:52');
INSERT INTO `sections` VALUES (6,'All of Photo','photo','','','articles','photo',1,1,5,7,1,'2013-04-25 15:09:10');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `jobtitle` varchar(512) NOT NULL,
  `fulltxt` text NOT NULL,
  `linkfile` text NOT NULL,
  `filename` text NOT NULL,
  `filesize` int(11) NOT NULL,
  `urls` varchar(512) NOT NULL,
  `phone` varchar(512) NOT NULL,
  `email` varchar(256) NOT NULL,
  `sectionid` int(11) unsigned NOT NULL DEFAULT '0',
  `categoriesid` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `views` int(11) NOT NULL DEFAULT '0',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'김 지연 목사','담임 목사','<p>미주한인 예수교 장로호(KAPC) 카나다 노회 소속 목사입니다. <br />1995년 캐나다에 와서 같은 해 토론토 은평교회에서 찬양사역과 청년사역을 2014년까지 해왔으며, 2014년 9월 7일 하나님의 부르심에 순종하여 토론토 다운타운에 TORONTO CONNCET 교회를 시작하여 \"하나님 사랑 이웃 사랑\"의 비젼으로 이 땅에 진정한 회복과 치유 그리고 변화의 부흥을 꿈꾸는 행복한 목회자입니다.</p>\r\n<p>또한 1997년 9월에 토론토 유학생 선교회를 시작하여 17년간의 공동체 생활을 통해 700여 명의 청년들을 \"복음이 없는 자에게 복음을 복음을 가진자에게 사명을\"이라는 케치프레이즈로 사역하고 있습니다.</p>','','images/201509/jiyun.png',9253,'','416-123-4567','jyk57&#64;hotmail.com',0,0,1,1,1,0,'2015-09-14 16:32:37',1,'2015-09-10 21:22:19',1);
INSERT INTO `staff` VALUES (2,'김 진섭 전도사','청년부 담당','<p>학교, 졸업과 직장 그리고 결혼 문제로 인해 이동이 쉬운 세대, 즉 이동성인 큰 청년 세대를 이해하고 이들과 호흡을 같이 하고자 노력하는 사역자입니다. 청년사역의 우선성을 두고자 하며 \'청년은 현존(現存)하는 미래이다.\'라 생각합니다. 또한 청년이 청년다움을 유지할 수 있게 그들을 품을 수 있는 맑고 투명한 공동체를 지향합니다.</p>','','images/201509/jinsub.png',9121,'','416-123-4567','jinsub8359&#64;hotmail.com',0,0,2,1,1,0,'2015-09-14 21:09:27',1,'2015-09-10 21:23:12',1);
INSERT INTO `staff` VALUES (3,'최 유봉 전도사','어린이 담당','<p>이스라엘아 들으라 우리 하나님 여호와는 오직 유일한 여호와이시니 너는 마음을 다하고 뜻을 다하고 힘을 다하여 네 하나님 여호와를 사랑하라 오늘 내가 네게 명하는 이 말씀을 너는 마음에 새기고 네 자녀에게 부지런히 가르치며 집에 앉았을 때에든지 길을 갈 때에든지 누워 있을 때에든지 일어날 때에든지 이 말씀을 강론할 것이며 너는 또 그것을 네 손목에 매어 기호를 삼으며 네 미간에 붙여 표로 삼고또 네 집 문설주와 바깥 문에 기록할지니라 (신명기 6:4-9)</p>','','images/201509/yubong.png',9923,'','416-123-2456','email&#64;email.com',0,0,3,1,1,0,'2015-09-14 17:23:46',1,'2015-09-10 21:23:49',1);
INSERT INTO `staff` VALUES (4,'송 유진 간사','행정 담당','<p>전반적인 교회 사무와 행정, 그리고 헌금 및 헌금 외 수입등을 계수하고 집행하는 일을 담당합니다. 교회 존재의 최고 목적이 그리스도의 몸 된 공동체 설립과 복음사역에 집중 되어 있는 만큼, 모든 행정과 재정이 올바르게 세워지고 사용될 수 있도록 노력합니다. </p>','','images/201509/yujin.png',10882,'','416-123-2456','erin.song87&#64;hotmail.com',0,0,4,1,1,0,'2015-09-14 17:37:50',1,'2015-09-10 21:24:25',1);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-15 11:37:38
